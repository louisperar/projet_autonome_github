from flask import request, redirect
import jwt
from utils import PathUtils
import os


def RedirectToLoginURL() -> redirect:
    return redirect("/auth/ui/login?redirect="+request.url, code=302)


def authentification(role: str) -> bool:
    if os.getenv("SKIP_AUTH", "false") == "true":
        return True
    if request.cookies.get('token') is not None:
        token = request.cookies.get('token')
    else:
        try:
            authorization = request.headers['Authorization'].split(" ")
            if authorization[0] == "Bearer":
                token = authorization[1]
            else:
                return False
        except KeyError as _:
            return False

    pUtils = PathUtils()
    with open(pUtils.getSharedPath() / "jwt_rsa.pem", mode="rb") as pubkey:
        try:
            data = jwt.decode(token, pubkey.read(), algorithms="RS256")
        except jwt.exceptions.InvalidSignatureError:
            return False
        except jwt.exceptions.DecodeError:
            return False
        except jwt.ExpiredSignatureError:
            return False
        except jwt.exceptions.InvalidAlgorithmError:
            return False
    if role == "read":
        if "serveurs" in data["permissions"]["read"]:
            return True
        else:
            return False
    if role == "write":
        if "serveurs" in data["permissions"]["write"]:
            return True
        else:
            return False
    return False
