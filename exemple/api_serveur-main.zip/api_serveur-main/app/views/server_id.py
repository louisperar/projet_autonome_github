from flask import Response, request, jsonify
from database import db
from models.server import Servers
from views.auth import RedirectToLoginURL, authentification
import time


def server_idGET(id: int) -> Response:
    if request.content_type == "application/json":
        return server_idGETAPI(id)
    else:
        return server_idGETHTML(id)


def server_idPATCHAPI(id: int):
    if authentification("read"):
        try:
            server = Servers.query.get(id)
            patch_data = request.get_json()
            if "name" in patch_data.keys():
                server.name = patch_data["name"]

            if "type_server" in patch_data.keys():
                server.type_server = patch_data["type_server"]

            if "os" in patch_data.keys():
                server.os = patch_data["os"]

            if "system_version" in patch_data.keys():
                server.system_version = patch_data["system_version"]

            if "location" in patch_data.keys():
                server.location = patch_data["location"]

            if "status" in patch_data.keys():
                server.status = patch_data["status"]

            if "cpu" in patch_data.keys():
                server.cpu = patch_data["cpu"]

            if "ram" in patch_data.keys():
                server.ram = int(patch_data["ram"])

            if "ip" in patch_data.keys():
                server.ip = patch_data["ip"]

            server.last_modif = f"{time.time()}"

            db.session.commit()

            return id
        except Exception as e:
            print(e)
            return jsonify({"Message": "Bad request"}), 400
    else:
        return jsonify({"Message": "Unauthorized"}), 403


def server_idPATCHHTML(id: int):
    return id


def server_idPATCH(id: int) -> Response:
    if request.content_type == "application/json":
        return server_idPATCHAPI(id)
    else:
        return server_idPATCHHTML(id)


def server_idGETAPI(id: int) -> Response:
    if authentification("read"):
        try:
            server = Servers.query.get(id)
            return jsonify(server.serialize()), 200

        except Exception as e:
            print(e)
            return jsonify({"Message": "Not Found"}), 404
    else:
        return jsonify({"Message": "Unauthorized"}), 403


def server_idGETHTML(id: int) -> Response:
    return id


def server_idDELETE(id: int) -> Response:
    if authentification("write"):
        try:
            server = Servers.query.get(id)
            db.session.delete(server)
            db.session.commit()
            return "", 200
        except Exception as e:
            return jsonify({"Message": "Not found"}), 404
