from flask import jsonify, request, Response, render_template, redirect
from views.auth import RedirectToLoginURL, authentification
from database import db
from models.server import Servers
import time


def serverGET() -> Response:
    if request.content_type == "application/json":
        return serverGETAPI()
    else:
        return serverGETHTML()


def serverGETAPI() -> Response:
    if authentification("read"):
        serveurs = Servers.query.all()
        liste = []
        for serveur in serveurs:
            liste.append(serveur.serialize())
        return jsonify(liste), 200
    else:
        return jsonify({"Message": "Unauthorized"}), 403


def serverGETHTML() -> Response:
    if authentification("read"):
        serveurs = Servers.query.all()
        print(serveurs)
        return render_template("index.html", servers=serveurs), 200
    else:
        return RedirectToLoginURL()


def serverPOST() -> Response:
    if request.content_type == "application/json":
        return serverPOSTAPI()
    else:
        return serverPOSTHTML()


def serverPOSTAPI() -> Response:
    if authentification("write"):
        try:
            post_data = request.get_json()
            name = post_data["name"]
            type_server = post_data["type_server"]
            os = post_data["os"]
            system_version = post_data["system_version"]
            location = post_data["location"]
            status = post_data["status"]
            cpu = post_data["cpu"]
            ram = int(post_data["ram"])
            ip = post_data["ip"]
            last_modif = f"{time.time()}"

            server = Servers(name=name, type_server=type_server, os=os, system_version=system_version,
                             location=location, status=status, last_modif=last_modif, cpu=cpu, ram=ram, ip=ip)
            db.session.add(server)
            db.session.commit()
            return jsonify({"Message": "Ok"}), 200
        except Exception as e:
            print(e)
            return jsonify({"Message": "Bad Request"}), 403
    else:
        return jsonify({"Message": "Unauthorized"}), 403


def serverPOSTHTML() -> Response:
    if authentification("write"):
        try:
            name = request.form["name"]
            type_server = request.form["type"]
            os = request.form["os"]
            system_version = request.form["system_version"]
            location = request.form["location"]
            status = request.form["status"]
            cpu = request.form["cpu"]
            ram = int(request.form["ram"])
            ip = request.form["ip"]
            last_modif = f"{time.time()}"

            server = Servers(name=name, type_server=type_server, os=os, system_version=system_version,
                             location=location, status=status, last_modif=last_modif, cpu=cpu, ram=ram, ip=ip)
            db.session.add(server)
            db.session.commit()
            return redirect("/server", code=302)
        except Exception as e:
            print(e)
            return "Bad Request", 400
    else:
        return RedirectToLoginURL()
