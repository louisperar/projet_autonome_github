from sqlalchemy_serializer import SerializerMixin
from database import db


class Servers(db.Model, SerializerMixin):
    """Servers Model

    Matches the Users table in the database
    """
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    type_server = db.Column(db.String(255))
    os = db.Column(db.String(255))
    system_version = db.Column(db.String(255))
    location = db.Column(db.String(255))
    status = db.Column(db.String(255))
    last_modif = db.Column(db.String(255))
    cpu = db.Column(db.String(255))
    ram = db.Column(db.Integer)
    ip = db.Column(db.String(255))

    def __repr__(self):
        return f'<Users {self.id}>'

    def serialize(self):
        return {"id": self.id,
                "name": self.name,
                "type_server": self.type_server,
                "os": self.os,
                "system_version": self.system_version,
                "location": self.location,
                "location": self.location,
                "status": self.status,
                "last_modif": self.last_modif,
                "cpu": self.cpu,
                "ram": self.ram,
                "ip": self.ip,
                }
