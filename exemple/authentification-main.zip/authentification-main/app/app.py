import views
import os
import bcrypt
from flask import Flask
from database import db
from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database
from flask_swagger_ui import get_swaggerui_blueprint
from utils import PathUtils
from genkeys import Genkeys
from models.admins import Admins

    
class Application: 
    def __init__(self):
        self.app = Flask(__name__)
        db_c = {
            "host": os.getenv("DB_HOST", "localhost"),
            "user": os.getenv("DB_USER", "postgres"),
            "pass": os.getenv("DB_PASSWORD", "bonjour"),
            "name": os.getenv("DB_PROJECT", "project"),
            "port": os.getenv("DB_PORT", "5432")
        }
        self.sql_url = f"postgresql://{db_c['user']}:{db_c['pass']}@{db_c['host']}:{db_c['port']}/{db_c['name']}"
        self.app.config['SQLALCHEMY_DATABASE_URI'] = self.sql_url
        self.app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        self.app.config['DEBUG'] = (os.getenv("DEBUG", "FALSE") == "TRUE")
        self.app.config['template_folder'] = "templates/"
        self.app.config['static_folder'] = "static/"

        self.pUtils = PathUtils()

        if not os.path.isfile(self.pUtils.getDataPath() / ".firstrun"):
            print("Running first RUN")
            self.first_run()
        else :
            db.init_app(self.app)
        

        # DB check if all tables are created
        if os.getenv("DB_CREATE", "FALSE") == "TRUE":
            with self.app.app_context():
                print("Creating all tables")
                db.delete_all()
                db.create_all()

        self.init_routes()


    def first_run(self):
            print("############### RUNNING FIRST RUN SCRIPT ###############")
            engine = create_engine(self.sql_url)
            if not database_exists(engine.url):
                create_database(engine.url)
                print("> Database created")
            else :
                print("> Database already exists")
            db.init_app(self.app)
            print("> App started")
            with self.app.app_context():
                db.create_all()
                print("> Tables created")
                passwd = os.getenv("ADMIN_PASSWORD", "Sorry, rules are rules!")
                hashed_password = bcrypt.hashpw(passwd.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
                root_privileges = '{"read": ["serveurs","ordinateurs","logiciels","licences","ipam","utilisateurs","authentfication"],  "write": ["serveurs","ordinateurs","logiciels","licences","ipam","utilisateurs","authentfication"]}'
                user = Admins(id=1, password=hashed_password, permissions=root_privileges)
                db.session.add(user)
                db.session.commit()
                print("> ADMIN user created")


            Genkeys()
            print("> Key pair generated")
            open(self.pUtils.getDataPath() / ".firstrun", 'w').close()
            print("> Status saved")

    def run(self):
        self.app.run(debug=(os.getenv("DEBUG", "FALSE") == "TRUE"), use_reloader=True)

    def init_routes(self):
        self.app.add_url_rule('/ping', view_func=views.api.ping, methods=['GET'])
        self.app.add_url_rule('/auth/login', view_func=views.api.loginUser, methods=['POST'])

        self.app.add_url_rule('/auth/', view_func=views.gui.loginUser_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/login', view_func=views.gui.loginUser_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/logout', view_func=views.gui.logoutUser_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/', view_func=views.gui.profileUser_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/users', view_func=views.gui.listUsers_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/users/create', view_func=views.gui.createUser_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/users/create', view_func=views.gui.createUser_front, methods=['POST'])
        self.app.add_url_rule('/auth/ui/users/update/<int:user_id>', view_func=views.gui.updateUser_front, methods=['GET'])
        self.app.add_url_rule('/auth/ui/users/update/<int:user_id>', view_func=views.gui.updateUser_front, methods=['POST'])
        self.app.add_url_rule('/auth/ui/roles/edit/<id>', view_func=views.gui.listRoles_front, methods=['GET'])

        self.app.add_url_rule('/auth/user', view_func=views.api.listUsers, methods=['GET'])
        self.app.add_url_rule('/auth/user', view_func=views.api.createUser, methods=['POST'])
        self.app.add_url_rule('/auth/user/<int:user_id>', view_func=views.api.getUser, methods=['GET'])
        self.app.add_url_rule('/auth/user/<int:user_id>', view_func=views.api.deleteUser, methods=['DELETE'])
        self.app.add_url_rule('/auth/user/<int:user_id>', view_func=views.api.updateUser, methods=['PUT'])
        self.app.add_url_rule('/auth/role', view_func=views.api.getRole, methods=['GET'])
        self.app.add_url_rule('/auth/role/city/<city>', view_func=views.api.getRole, methods=['GET'])
        self.app.add_url_rule('/auth/role/<id>', view_func=views.api.getRoleById, methods=['GET'])
        self.app.add_url_rule('/auth/role/<id>/city/<city>', view_func=views.api.getRoleById, methods=['GET'])
        self.app.add_url_rule('/auth/role/<id>', view_func=views.api.setRole, methods=['PUT'])

        self.app.register_blueprint(
            get_swaggerui_blueprint(
                "/docs",  # Swagger UI static files will be mapped to '{SWAGGER_URL}/dist/'
                "/static/swagger.yaml",
            ))


app = Application()

# For wsgi (two arguments are required)
def start(environ, start_response):
    return app.app(environ, start_response)
    
if __name__ == '__main__':
    start()