from flask import jsonify, Response, request
from models.admins import Admins
from utils import GetUserSession, RedirectToLoginURL

def listUsers() -> Response:
    """Get method to list all users
    """
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    users = Admins.query.all()

    return jsonify([user.toDict() for user in users]), 200