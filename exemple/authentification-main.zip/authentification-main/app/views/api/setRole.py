from flask import Response, jsonify, request
from utils import SendError, GetUserSession, GetRights
from models.admins import Admins
from models.roles import Roles
from database import db

def setRole(id :int) -> Response:
    isLoggedIn, data, r = GetUserSession()
    if (not isLoggedIn) and (r is not None):
        return r
    elif not isLoggedIn:
        return SendError(data)

    isAuthorized, error = GetRights(data, "authentfication", "w")
    if not isAuthorized:
        return error

    if len(Admins.query.filter_by(id=id).all()) != 1:
        return SendError("Admin is not found", 404)

    try:
        body = request.get_json()
        Roles.query.filter_by(id=id).delete()
        db.session.commit()
        for c in body:
            r = body[c]
            if c == "_" and r == "superadmin":
                role = Roles(id=id, rank=r)
            elif r == "user" or r =="dsi_local":
                role = Roles(id=id, city=c, rank=r)
            db.session.add(role)
        db.session.commit()
        return jsonify({"status": "success"})

        

    except Exception as e:
        return SendError("Please provide a valid JSON", 500, str(e))
    
    
