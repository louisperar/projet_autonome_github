from flask import Response, jsonify
from utils import SendError, GetUserSession, GetRights
from models.roles import Roles


def getRoleById(id :int, city :str=None) -> Response:
    isLoggedIn, data, r = GetUserSession()
    if (not isLoggedIn) and (r is not None):
        return r
    elif not isLoggedIn:
        return SendError(data)

    isAuthorized, error = GetRights(data, "authentfication", "ro")
    if not isAuthorized:
        return error

    roles = Roles.query.filter_by(id=id).all()
    print(id)
    if len(roles) == 0:
        return SendError("User not found", 404)
    if city is None:
        sorted_roles = {}
        for role in roles:
            if city is not None:
                pass
            if (role.city is None) and role.rank == "superadmin":
                sorted_roles['_'] = "superadmin"
            elif role.city not in sorted_roles.keys() and (role.rank == "dsi_local" or role.rank == "user"):
                sorted_roles[role.city] = role.rank
        return jsonify(sorted_roles)
    else:
        for role in roles:
            if str(role.city).lower() == city.lower():
                return jsonify(role.rank)
        return SendError("City not found for the connected user", 418)   
    
    
