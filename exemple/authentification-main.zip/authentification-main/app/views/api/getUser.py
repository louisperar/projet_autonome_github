from flask import jsonify, Response, request
from models.admins import Admins
from utils import RedirectToLoginURL, GetUserSession

def getUser(user_id: int) -> Response:
    """Retrieve a specific user by id
    """
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    user = Admins.query.filter_by(id=user_id).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify(user.toDict()), 200