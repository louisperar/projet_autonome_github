from flask import jsonify, Response, request
from models.admins import Admins
from utils import RedirectToLoginURL, GetUserSession

def createUser() -> Response:
    """Post method to create a user
    """
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    # Retrieve POST data
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    # Check if all fields are present
    user = Admins()
    user.fromJSON(data)
    user.hashPassword()

    if not user.validate():
        return jsonify({"error": "Missing fields"}), 400

    # Check if user already exists
    if Admins.query.filter_by(id=user.id).first():
        return jsonify({"error": "User already exists"}), 400

    user.save()

    return jsonify({"success": "User created"}), 200