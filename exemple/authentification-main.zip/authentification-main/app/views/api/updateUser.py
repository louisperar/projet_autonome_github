from flask import jsonify, Response, request
from utils import GetUserSession, RedirectToLoginURL
from models.admins import Admins

def updateUser(user_id: int) -> Response:
    """PUT method to update a user"""
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    # Retrieve POST data
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    # Get old user
    user = Admins.query.filter_by(id=user_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404

    if data.get("password"):
        user.password = data["password"]
        user.hashPassword()

    if data.get("permissions"):
        user.permissions = data["permissions"]

    if data.get("github_id"):
        user.github_id = data["github_id"]

    if not user.validate():
        return jsonify({"error": "Missing fields"}), 400

    # Update user
    user.update()
    return jsonify({"success": "User updated"}), 200