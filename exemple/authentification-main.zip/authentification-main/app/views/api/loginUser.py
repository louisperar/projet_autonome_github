from flask import jsonify, Response, request, make_response
from models.admins import Admins
from utils import PathUtils, SendError
import requests
import base64
import binascii
import bcrypt
import jwt
import time
import json
import os


def loginUser() -> Response:
    """
    Post method to login a user
    """
    try:
        authorization = request.headers['Authorization'].split(" ")
        if authorization[0] == "Basic":
            user_pass = str(base64.b64decode(authorization[1]), encoding='utf-8').split(":")
            if len(user_pass) != 2:
                return SendError("Please use HTTP basic auth header")
            username = user_pass[0]
            password = user_pass[1]
            if (username is None) or username == "":
                return SendError("Invalid username")
            if (password is None) or password == "":
                return SendError("Invalid password")
            url = "http://app-api-users:5000/users/user/findby?username="+username
            r = requests.get(url, timeout=5)
            if r.status_code == 404:
                return SendError("User not found or incorrect password", 401, "User not found")
            if not r.ok:
                return SendError("API not reachable", 503)
            data = r.json()[0]

            user = Admins.query.filter_by(id=data['id']).first()

            if user is None:
                # Throw error
                return SendError("User not found or incorrect password", 401, "User is not admin !")
            if bcrypt.checkpw(password=password.encode('utf-8'), hashed_password=user.password.encode('utf-8')):
                issued_at = int(time.time())
                expire_at = issued_at + 3600 # Expire 1 hour later

                payload = {
                    "Id": data['id'],
                    "username": username,
                    "permissions" : json.loads(user.permissions),
                    "iat": issued_at,
                    "exp": expire_at
                }
                pUtils = PathUtils()
                with open(pUtils.getDataPath() / "private.pem", mode="rb") as key:
                    token = jwt.encode(payload, key.read(), algorithm="RS256")
                    print(f"New session at {issued_at} : {token}")
                    response = make_response(jsonify({"status": "success", "token": token}))
                    response.set_cookie('token', token)
                    return response
            else:
                return SendError("User not found or incorrect password", 401, "Passwords don't match")
        else:
            return SendError("Invalid authentication method")
    except KeyError:
        return SendError("Please provide username and password as HTTP basic auth header")
    except binascii.Error:
        return SendError("Please use HTTP basic auth header")
    except requests.exceptions.ConnectionError as e:
        return SendError("API not reachable", 503, str(e))
    except json.decoder.JSONDecodeError as e:
        return SendError("Corrupted database !", 500, str(e))
