import json
from flask import Response, render_template, redirect, request
from utils import SendError, GetUserSession, RedirectToLoginURL, Kirbi
from models.admins import Admins

def updateUser_front(user_id: int) -> Response:
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    errors = []
    # If POST request, create user
    if request.method == "POST":
        if not user_id:
            errors.append("User not found")
        else:
            # Get old user
            user = Admins.query.filter_by(id=user_id).first()
            if not user:
                   errors.append("User not found")
            else:
                if request.form.get("password"):
                    user.password = request.form.get("password")
                    user.hashPassword()

                user.permissions = json.dumps({
                    "write": request.form.getlist("write"),
                    "read": request.form.getlist("read"),
                })

                if request.form.get("github_id"):
                    user.github_id = request.form.get("github_id")

                if not user.validate():
                    errors.append("Missing fields")
                else:
                    # Update user
                    user.update()
                    return redirect("/auth/ui/users?success=userUpdated", code=302)

    liste_apis = Kirbi.liste_apis()
    user = Admins.query.filter_by(id=user_id).first()
    if not user:
        return SendError("User not found", 404)

    u_data = GetUserSession.request("http://app-api-users:5000/users/user", "GET").json()
    for u in u_data:
        if u.get("id") == user_id:
            u_data = u
            break

    if not u_data:
        return SendError("User not found", 404)

    u_data["permissions"] = json.loads(user.permissions)

    return render_template("updateUser.html.j2", **locals())
