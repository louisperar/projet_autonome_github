from flask import Response, render_template, request
from utils import SendError, GetUserSession, RedirectToLoginURL
from models.admins import Admins


def listUsers_front() -> Response:
    def getUserById(id: int):
        for user in users:
            if user.id == id:
                return user
        return None

    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    successAlerts = request.args.get("success")

    liste_utilisateurs_models = GetUserSession.request("http://app-api-users:5000/users/user", "GET").json()
    liste_utilisateurs = {}
    for user in liste_utilisateurs_models:
        liste_utilisateurs[user["id"]] = user

    users = Admins.query.all()
    users.sort(key=lambda x: x.id)

    return render_template("listUsers.html.j2", **locals())
