import json
from flask import Response, render_template, redirect, request
from utils import SendError, GetUserSession, RedirectToLoginURL, Kirbi
from models.admins import Admins

def createUser_front() -> Response:
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    errors = []
    # If POST request, create user
    if request.method == "POST":
        user_id = GetUserSession.request("http://app-api-users:5000/users/user/findby?username="+request.form.get("username"), "GET").json()
        if not user_id or len(user_id) == 0 or not user_id[0].get("id"):
            errors.append("User not found")
        else:
            new_user = Admins(
                id=user_id[0].get("id"),
                password=request.form.get("password"),
                permissions=json.dumps({
                    "write": request.form.getlist("write"),
                    "read": request.form.getlist("read"),
                })
            )
            new_user.hashPassword()

            if not new_user.validate():
                errors.append("Missing fields")
            elif Admins.query.filter_by(id=new_user.id).first():
                errors.append("User already exists")
            else:
                new_user.save()
                # Redirect to listUsers
                return redirect("/auth/ui/users?success=userAdded", code=302)

    liste_apis = Kirbi.liste_apis()

    liste_utilisateurs = GetUserSession.request("http://app-api-users:5000/users/user", "GET").json()

    return render_template("createUser.html.j2", **locals())
