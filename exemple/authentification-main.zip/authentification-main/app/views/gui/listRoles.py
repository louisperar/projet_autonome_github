from flask import Response, render_template, abort
from utils import SendError, GetUserSession, RedirectToLoginURL, GetRights
from models.roles import Roles

def listRoles_front(id :int) -> Response:
    isLoggedIn, user_data, r = GetUserSession()

    if not isLoggedIn:
        return RedirectToLoginURL()
    isAuthorized, error = GetRights(user_data, "authentfication", "ro")
    if not isAuthorized:
        return error

    roles = Roles.query.filter_by(id=id).all()
#    if len(roles) == 0:
#        return abort(500)
    sorted_roles = {}
    is_super_admin = "Non"
    translate = {"dsi_local": "DSI locale", "user": "Utilisateur"}
    for role in roles:
        if (role.city is None) and role.rank == "superadmin":
           is_super_admin = "Oui"
        elif role.city not in sorted_roles.keys() and (role.rank == "dsi_local" or role.rank == "user"):
            sorted_roles[role.city] = translate[role.rank]
    print(sorted_roles)
    user = GetUserSession.request("http://app-api-users:5000/users/user/" + id, "GET").json()

    return render_template("listRoles.html.j2", **locals())
