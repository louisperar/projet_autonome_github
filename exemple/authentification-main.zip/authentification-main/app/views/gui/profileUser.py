from flask import Response, render_template
from utils import SendError, GetUserSession, RedirectToLoginURL
import ast

def profileUser_front() -> Response:
    isLoggedIn, user_data, r = GetUserSession()
    if not isLoggedIn:
        return RedirectToLoginURL()

    user_details = GetUserSession.request("http://app-api-users:5000/users/user/findby?username=" + user_data["username"], "GET").json()[0]
    return render_template("profileUser.html.j2", **locals())