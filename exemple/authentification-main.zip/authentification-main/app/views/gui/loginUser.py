from flask import Response, render_template, redirect, request, jsonify
from utils import SendError, GetUserSession


def loginUser_front() -> Response:
    isLoggedIn, data, r = GetUserSession()

    # If page is /auth/ redirect to /login
    if request.path == "/auth/":
        # If API request (Accept: application/json)
        if "application/json" in request.headers.get("Accept", "") and isLoggedIn:
            # Return user profile
            return jsonify(data), 200
        return redirect("/auth/ui/login", code=302)

    if isLoggedIn:
        return redirect("/auth/ui/", code=302)

    return render_template("loginUser.html.j2", **locals())
