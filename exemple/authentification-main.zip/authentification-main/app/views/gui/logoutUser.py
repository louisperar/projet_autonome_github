from flask import Response, redirect, make_response
from utils import SendError, GetUserSession


def logoutUser_front() -> Response:
    """
    Suppression du cookie de session
    """
    isLoggedIn, _, _ = GetUserSession()
    if not isLoggedIn:
        return redirect("/auth/", code=302)

    response = make_response(redirect("/auth/", code=302))
    response.delete_cookie('token')
    return response
