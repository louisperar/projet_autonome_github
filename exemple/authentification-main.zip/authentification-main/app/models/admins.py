import json
from database import db
import bcrypt
from sqlalchemy.sql import func
import ast

class Admins(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    password = db.Column(db.String(255), nullable=True)
    permissions = db.Column(db.Text, nullable=False)
    github_id = db.Column(db.String(80), unique=True, nullable=True)
    created_at = db.Column(db.DateTime(timezone=True),
                           server_default=func.now())
    def __repr__(self):
        return f'<Admins {self.id}>'

    def __str__(self):
        return f'<Admins (id={self.id}, password={self.password}, permissions={self.permissions}, github_id={self.github_id})>'

    def validate(self) -> bool:
        if self.id is None:
            return False
        if self.password is None:
            return False
        if self.permissions is None:
            return False
        #if self.github_id is None:
        #    return False
        return True

    def fromJSON(self, data):
        if "id" in data:
            self.id = data["id"]
        if "password" in data:
            self.password = data["password"]
        if "permissions" in data:
            self.permissions = json.dumps(data["permissions"])
        if "github_id" in data:
            self.github_id = data["github_id"]
        return self

    def toDict(self):
        return {
            "id": self.id,
            "permissions": self.permissions,
            "github_id": self.github_id,
            "created_at": self.created_at
        }

    def save(self):
        db.session.add(self)
        db.session.commit()
        return self

    def update(self):
        db.session.commit()
        return self

    def delete(self):
        db.session.delete(self)
        db.session.commit()
        return self

    def hashPassword(self) -> str:
        self.password = bcrypt.hashpw(self.password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    def permissionsToDict(self) -> dict:
        return ast.literal_eval(self.permissions)