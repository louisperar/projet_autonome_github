# Groupe Authentification

Permet de s'authentifier et de gérer les rôles d'un utilisateur. Une définition OpenAPI est disponible. Le token (cookie ou header) est un JWT, pour un exemple d'utilisation [voir ici](https://github.com/DevCloudSM/python3-boilerplate/blob/main/app/views/testJWT.py)
