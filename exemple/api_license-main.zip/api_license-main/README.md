# api_license
_Gestion des licences en lien avec des sites physiques par des DSI locaux ou bien le Super Admin_
## Données exploités
- Site                 | _ex : Saint Malo_
- Provider (Editeur)   | _ex : Microsoft_
- Product (Produit)    | _ex : Windows_
- License (Licence)    | _ex : Windows Serveur 2019_
