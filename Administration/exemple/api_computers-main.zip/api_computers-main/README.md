# API Ordinateurs

## Objectifs
L'API de gestion des ordinateurs permet d'obtenir toutes les informations de tous les ordinateurs. Il est également possible d'obtenir les informations d'un ordinateur spécifique (avec son ID) et d'appliquer des filtres pour obtenir des informations spécifiques sur un ou plusieurs ordinateurs. Il est également possible pour les administrateurs d'ajouter, supprimer ou modifier un ordinateur. L'utilisateur peut seulement rechercher un pc par ID.

## Utilisateurs
### Utilisateur "Classique"
- **GET:** Obtenir les informations de base des ordinateurs.

### Utilisateur Administrateur
- **GET:** Accéder à toutes les informations de tous les ordinateurs.
- **PATCH:** Modifier les informations de tous les ordinateurs.
- **POST:** Ajouter un nouvel ordinateur.
- **DELETE:** Supprimer un ordinateur existant.

## Informations des Ordinateurs

### Super Admin
- id
- localisation
- Nom de l'ordinateur
- Propriétaire
- Type (portable / fixe)
- OS
- Version OS
- Liste logiciels
- CPU (ARM / x64)
- GPU
- Type GPU (dédié / intégré)
- RAM
- Disque (SSD / HDD)
- Carte mère
- Boitier
- Type d'authentification (mot de passe / clé de sécurité)
- Adresse IP
- Masque
- Passerelle
- DNS

### Administrateur local
- id
- localisation
- Nom de l'ordinateur
- Propriétaire
- Type (portable / fixe)
- OS
- Version OS
- Liste logiciels
- CPU (ARM / x64)
- GPU
- Type GPU (dédié / intégré)
- RAM
- Disque (SSD / HDD)
- Carte mère
- Boitier
- Type d'authentification (mot de passe / clé de sécurité)
- Adresse IP
- Masque
- Passerelle
- DNS

### Utilisateur Autre
- id
- Nom de l'ordinateur
- Propriétaire
- Type (portable / fixe)
- OS
- Version OS

## Endpoints

- `./api/computers` : 
  - |GET| -> Renvoie une liste des ordinateurs.
  - |POST| -> Ajoute un ordinateur (uniquement pour les administrateurs).
- `./api/computers/{computerId}` :
  -  |GET| -> Détails d'un ordinateur (avec liste des ordinateurs si ID non renseigné ou = 0 /!\ Vérifier si l'utilisateur est le propriétaire de l'ordinateur ou administrateur pour plus de détails).
  - |DELETE| -> Supprime un ordinateur (uniquement pour les administrateurs).
  - |PATCH| -> Modifie un ordinateur (attribut dépend de l'utilisateur (administrateur / utilisateur) /!\ Vérifier si l'utilisateur est le propriétaire de l'ordinateur).
- `./api/computers/findBy` -> |GET| -> Recherche par filtre.

Comme vu précédemment nous avons pour chaque méthode une page HTML lié. Donc chaque lien ci-dessous est une page d'affichage donc une requête |GET|

- `./` -> Permet de savoir si le service est en ligne en affichant le menu.
- `./computers/search` -> |GET| -> Nous affiche une page sur laquelle on peut faire des recherches par ID et seulement ID. Elle nous affiche de base une liste d'ordinateurs avec les informations minimales si nous ne sommes pas en connecter en administrateur. Si l'administrateur est connecté alors il a toutes les informations sur les ordinateurs. (requête lié `./api/computers/{computerID}` méthode |GET|)
- `./computers/search_advanced` -> |GET| -> Nous envoies sur une page qui a les mêmes fonctionnalités que la page search les différences sont que l'on peut filtrer par tous les paramètres autre que l'ID et est seulement accessible par les administrateurs. (requête lié `./api/computers/findBy` méthode |GET|)
- `./computers/add` -> |GET| -> Renvoie une page où l'on rentre les informations de l'ordinateur que l'on veut ajouté. Utilisable par tout le monde. (requête lié `./api/computers` méthode |POST|)
- `./computers/delete/{computerId}` -> |GET| -> Renvoie une page où l'on rentre l'ID de l'ordinateur que l'on veut supprimé. Utilisable seulement par les administrateurs. (requête lié `./api/computers/{computerID}` méthode |DELETE|)
- `./computers/patch/{computerId}`-> |GET| -> Renvoie une page où l'on rentre l'ID et les informations de l'ordinateur que l'on veut modifié. Utilisable seulement par les administrateurs et l'utilisateur qui l'a crée. (requête lié `./api/computers/{computerID}` méthode |PATCH|)