from sqlalchemy import text, inspect
from flask import Flask, request, jsonify, render_template, redirect, url_for

def querry(db, querry):
    query = text(querry)
    result = db.session.execute(query)
    computer_dicts = [{list(result.keys())[i]: computer[i] for i in range(len(result.keys()))} for computer in result.fetchall()]
    return jsonify(computer_dicts)

def delete(db, id):
    query = text(f"DELETE FROM computer WHERE id = {id}")
    try:
        db.session.execute(query)
        db.session.commit() 
        return True
    except Exception as e:
        print("Error:", e)
        db.session.rollback()  
        return f"Failed to delete computer with ID {id}. Error: {str(e)}"

def update(db, params:str, id:int):
    query = text(f"UPDATE computer SET {params} WHERE id = {int(id)}")
    try:
        db.session.execute(query)
        db.session.commit()  
        return True
    except Exception as e:
        print("Error:", e)
        db.session.rollback()  
        return f"Failed to update computer with ID {id}. Error: {str(e)}"

def add(db, params: dict):
    keys = ', '.join(params.keys())
    values = ', '.join([f"'{value.upper()}'" for value in params.values()])
    query = text(f"INSERT INTO computer ({keys}) VALUES ({values})")
    print(f"INSERT INTO computer ({keys}) VALUES ({values})")
    try:
        db.session.execute(query)
        db.session.commit() 
        return True
    except Exception as e:
        print("Error:", e)
        db.session.rollback() 
        return False

