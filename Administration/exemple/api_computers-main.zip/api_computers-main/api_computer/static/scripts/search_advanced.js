const origine = window.location.origin;

async function displayComputerList(url) {
    try {
        console.log(origine + '/api/computer/' + String(url))
        const response = await fetch(origine + '/api/computer/' + url);
        const data = await response.json();
        
        if (Array.isArray(data)) {
            if (data.length === 0) {
                console.log('Aucun ordinateur trouvé.');
            } else {
                const computerList = document.getElementById('computer-list');
                computerList.innerHTML = '';
                data.forEach(computer => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${computer.id}</td>
                        <td>${computer.name}</td>
                        <td>${computer.owner}</td>
                        <td>${computer.type}</td>
                        <td>${computer.os}</td>
                        <td>${computer.os_version}</td>
                        <td>${computer.cpu}</td>
                        <td>${computer.gpu}</td>
                        <td>${computer.ram}</td>
                        <td>${computer.disk}</td>
                        <td>${computer.motherboard}</td>
                        <td>${computer.ip_address}</td>
                        <td>${computer.subnet_mask}</td>
                        <td>${computer.gateway}</td>
                        <td>${computer.dns}</td>
                    `;
                    computerList.appendChild(tr);
                });
                document.getElementById('addComputerForm').reset();
            }
        } else {
            console.error('Data received is not an array:', data);
        }
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}


document.getElementById('addComputerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const jsonData = {};
    formData.forEach((value, key) => {
        if (value !== '') {
            jsonData[key] = value;
        }
    });
    try {
        const response = await fetch(origine + '/api/computer/findby?' + new URLSearchParams(jsonData).toString(), {
            method: 'GET'
        });
        console.log(response.ok)
        if (response.ok) {
            document.getElementById('message').innerHTML = "Recherche efféctué avec succès !";
            document.getElementById('message').className = "alert alert-success";
            await displayComputerList("findby?" + new URLSearchParams(jsonData).toString());
        } else if (response.status == 440) {
            document.getElementById('message').innerHTML = "Aucune ressource trouvé.";
            document.getElementById('message').className = "alert alert-danger";
            console.error('Error computer:', response.statusText);
        }
        else {
            document.getElementById('message').innerHTML = "Problème lors de la recherche.";
            document.getElementById('message').className = "alert alert-danger";
            console.error('Error computer:', response.statusText);
        }
    } catch (error) {
        document.getElementById('message').innerHTML = "Problème lors de la recherche.";
        document.getElementById('message').className = "alert alert-danger";
        console.error('Error computer:', error);
    }
});

document.getElementById('refresh-button').addEventListener('click', async function() {
    await displayComputerList();
});

displayComputerList("0");