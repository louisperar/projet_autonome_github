const origine = window.location.origin;

async function displayComputerList() {
    try {
        const response = await fetch(origine + '/api/computer');
        const data = await response.json();
        const computerList = document.getElementById('computer-list');
        computerList.innerHTML = '';
        data.forEach(computer => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${computer.id}</td>
                <td>${computer.name}</td>
                <td>${computer.owner}</td>
                <td>${computer.type}</td>
                <td>${computer.os}</td>
                <td>${computer.os_version}</td>
                <td>${computer.cpu}</td>
                <td>${computer.gpu}</td>
                <td>${computer.ram}</td>
                <td>${computer.disk}</td>
                <td>${computer.motherboard}</td>
                <td>${computer.ip_address}</td>
                <td>${computer.subnet_mask}</td>
                <td>${computer.gateway}</td>
                <td>${computer.dns}</td>
            `;
            computerList.appendChild(tr);
        });
        document.getElementById('patchComputerForm').reset();
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

document.getElementById('patchComputerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const jsonData = {};
    formData.forEach((value, key) => {
        jsonData[key] = value;
    });
    console.log(jsonData)
    try {
        const response = await fetch(origine + '/api/computer/' + jsonData["id"], {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(jsonData)
        });
        console.log(response.ok)
        if (response.ok) {
            document.getElementById('message').innerHTML = "Ordinateur modifié avec succès !";
            document.getElementById('message').className = "alert alert-success";
            await displayComputerList();
        } else {
            document.getElementById('message').innerHTML = "Problème lors de la modification.";
            document.getElementById('message').className = "alert alert-danger";
            console.error('Error modifying computer:', response.statusText);
        }
    } catch (error) {
        document.getElementById('message').innerHTML = "Problème lors de la modification.";
        document.getElementById('message').className = "alert alert-danger";
        console.error('Error modifying computer:', error);
    }
});

document.getElementById('refresh-button').addEventListener('click', async function() {
    await displayComputerList();
});

displayComputerList();