var pattern = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight'];
var current = 0;
var keyHandler = function (event) {
	if (pattern.indexOf(event.key) < 0 || event.key !== pattern[current]) {
		current = 0;
		return;
	}
	current++;
	if (pattern.length === current) {
		current = 0;
        document.getElementById('contenu').innerHTML = "<iframe src='/tetris' width='400' height='700' frameborder='0'></iframe>";
	}
};
document.addEventListener('keydown', keyHandler, false);