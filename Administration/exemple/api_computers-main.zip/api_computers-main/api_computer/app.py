from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_cors import cross_origin
from functions import querry, delete, update, add
import requests, auth.methods as methods
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
#postgresql://username:password@hostname:port/database_name
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://admin:bonjour@10.0.0.2:5432/api'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///computer.db'
db = SQLAlchemy()
db.init_app(app)

port = 5000
limit_request = 50

#########################################
#-------------   API/JSON   ------------#
#########################################

@app.route("/api/computer", methods=["POST", "GET"])
@cross_origin()
def api_computer():
    """
    Add a new computer or get all computers.

    Methods:
        GET: Returns a tuple containing the computer information and the HTTP status code.
            The computer information is a list of dictionaries.
            The HTTP status code is an integer.
        POST: Adds a new computer to the database and returns a success message with HTTP status code.

    Returns:
        tuple: A tuple containing the response message and the HTTP status code.
    """
    if request.method == "GET":
        return (querry(db, f"SELECT * FROM computer LIMIT {limit_request}")).json, 200

    elif request.method == "POST":
        parameters = (querry(db, "SELECT * FROM computer LIMIT 1")).json[0].keys()
        data_request = request.json
        present = [(element in parameters, element) for element in list(data_request.keys())]
        if len(present) == 0:
            return 'No Argument', 400
        elif all(boolean[0] for boolean in present):
            if add(db, data_request):
                return 'Ressource Add', 200
            else:
                return 'Error During Add', 400
        else:
            print({'message':'Parameter(s) Not Found', 'info': present})
            return jsonify({'message':'Parameter(s) Not Found', 'info': present}), 404
    else:
        return 'Method unauthorized', 405

@app.route("/api/computer/<int:computer_id>", methods=["GET", "DELETE", "PATCH"])
@cross_origin()
def api_omputerid(computer_id:int=0):
    """
    Get, delete or update computer information by computer ID.

    Args:
        computer_id (int): The ID of the computer.

    Methods:
        GET: Returns a tuple containing the computer information and the HTTP status code.
            The computer information is a list of dictionaries.
            The HTTP status code is an integer.
        DELETE: Deletes the computer with the given ID and returns a success message with HTTP status code.
        PATCH: Updates the computer with the given ID and returns a success message with HTTP status code.

    Returns:
        tuple: A tuple containing the response message and the HTTP status code.
    """
    if request.method == 'GET':
        if int(computer_id) == 0:
            return (querry(db, f"SELECT * FROM computer LIMIT {limit_request}")).json, 200
        else:
            data = querry(db, f'SELECT * FROM computer WHERE "id" = {computer_id} LIMIT {limit_request}')
            if len(data.json) == 0:
                return 'Ressource Not Found', 400
            else:
                return data, 200

    elif request.method == 'DELETE':
        #exist = str(requests.get(f"http://127.0.0.1:{port}/api/computer/{computer_id}").status_code)
        if computer_id == 0:
            return 'Unable to delete everything', 403
        elif querry(db, f'SELECT * FROM computer WHERE "id" = {computer_id} LIMIT 1').json:
            if delete(db, computer_id):
                return 'Ressource Deleted', 200
            else:
                return 'Error During Deletion', 400
        else:
            return f'Id not found', 400

    elif request.method == 'PATCH':
        #exist = str(requests.get(f"http://127.0.0.1:{port}/api/computer/{computer_id}").status_code)
        if computer_id == 0:
            return 'Unable to patch everything', 403
        elif querry(db, f'SELECT * FROM computer WHERE "id" = {computer_id} LIMIT 1').json:
            parameters = (querry(db, "SELECT * FROM computer LIMIT 1")).json[0].keys()
            data_request = request.json
            present = [(element in parameters, element) for element in list(data_request.keys())]
            if len(present) == 0:
                return 'No Argument', 400
            elif all(boolean[0] for boolean in present):
                condition = ", ".join([ f"{key} = '{elt}'" for key, elt in data_request.items() if elt != ""])
                if update(db, condition, computer_id):
                    return 'Ressource Update', 200
                else:
                    return 'Error During Update', 400
            else:
                return jsonify({'message':'Parameter(s) Not Found', 'info': present}), 404
        else:
            return f'Id not found', 400
    else:
        return 'Method unauthorized', 405

@app.route("/api/computer/findby", methods=["GET"])
def api_get_computer_filtered():
    """
    Get computer information based on filter parameters.

    Args:
        request.args (dict): The filter parameters.

    Returns:
        tuple: A tuple containing the computer information and the HTTP status code.
            The computer information is a list of dictionaries.
            The HTTP status code is an integer.
    """
    if request.method == "GET":
        parameters = (querry(db, "SELECT * FROM computer LIMIT 1")).json[0].keys()
        data_request = request.args
        present = [(element in parameters, element) for element in list(data_request.keys())]
        if len(present) == 0:
            return 'No Argument', 400
        elif all(boolean[0] for boolean in present):
            condition = " AND ".join([ f"{key} ILIKE  '%{elt}%'" for key, elt in data_request.items() if elt != ""])
            if len(condition) > 0 :
                data = querry(db, f"SELECT * FROM computer WHERE {condition} LIMIT {limit_request}").json
                if len(data) == 0:
                    return 'Ressource Not Found', 440
                else:
                    return data, 200
            else:
                return 'Empty Parameter', 440
        else:
            return jsonify({'message':'Parameter(s) Not Found', 'info': present}), 404
    else:
        return 'Method unauthorized', 405

#########################################
#-------------   API/HTML   ------------#
#########################################

navbar_html = [ {"id":"1", "name":"Rechercher par ID", "url":"/computer/search"},
                {"id":"2", "name":"Recherche Avancée", "url":"/computer/search_advanced"},
                {"id":"3", "name":"Ajouter", "url":"/computer/add"},
                {"id":"4", "name":"Modifier", "url":"/computer/patch"},
                {"id":"5", "name":"Suppression", "url":"/computer/delete"}]

# Route d'accueil
@app.route('/')
def computer():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    return render_template( "index.html",
                            navbar=navbar_html,
                            user_name=token["username"])

@app.route("/computer/search", methods=["GET"])
def search_computer():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_read(token):
        return render_template( "search.html",
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "search_no_perm.html",
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200

@app.route("/computer/search_advanced", methods=["GET"])
def search_advanced_computer():
    #token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': [], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_read(token):
        return render_template( "search_advanced.html",
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html",
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/computer/add", methods=["GET"])
def add_computer():
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    #token = methods.token_reader()
    token = methods.token_reader()
    if methods.token_validate_write(token):
        return render_template( "add.html",
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html",
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/computer/delete", methods=["GET"])
def delete_computer():
    #token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_write(token):
        return render_template( "suppression.html",
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html",
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/computer/patch", methods=["GET"])
def patch_computer():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_write(token):
        return render_template( "patch.html",
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html",
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/tetris", methods=["GET"])
def tetris():
    return render_template( "tetris.html",
                            navbar=navbar_html,
                            accept=True,
                            list=False
                            ), 200

if __name__ == '__main__':
    app.run(debug=True)