from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect
from time import sleep

app = Flask(__name__)
#postgresql://username:password@hostname:port/database_name
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://admin:bonjour@10.0.0.2:5432/api'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///computer.db'
db = SQLAlchemy()
db.init_app(app)


class Computer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, default='DESKTOP_DEFAULT')
    owner = db.Column(db.String, default='UNKNOWN')
    type = db.Column(db.String, default='DESKTOP')
    os = db.Column(db.String, default='WINDOWS')
    os_version = db.Column(db.String, default='11')
    cpu = db.Column(db.String, default='UNKNOWN')
    gpu = db.Column(db.String, default='UNKNOWN')
    ram = db.Column(db.String, default='16')
    disk = db.Column(db.String, default='512')
    motherboard = db.Column(db.String, default='UNKNOWN')
    ip_address = db.Column(db.String, default='192.168.1.1')
    subnet_mask = db.Column(db.String, default='255.255.255.0')
    gateway = db.Column(db.String, default='192.168.1.254')
    dns = db.Column(db.String, default='192.168.1.253')

    def __repr__(self):
        return f"<Computer id:{self.id}, name:{self.name}, owner:{self.owner}, type:{self.type}, os:{self.os}, os_version:{self.os_version}, cpu:{self.cpu}, gpu:{self.gpu}, ram:{self.ram}, disk:{self.disk}, motherboard:{self.motherboard}, ip_address:{self.ip_address}, subnet_mask:{self.subnet_mask}, gateway:{self.gateway}, dns:{self.dns}>"

def add_computers():
    with db.session.no_autoflush:
        computers = [
            Computer(name='Desktop1', owner='John Doe', cpu='Intel i5', gpu='NVIDIA GTX 1660', ram='8GB'),
            Computer(name='Laptop1', owner='Jane Smith', cpu='AMD Ryzen 7', gpu='AMD Radeon RX 5600M', ram='16GB'),
            Computer(name='Server1', owner='Admin', cpu='Intel Xeon', gpu='N/A', ram='64GB'),
            Computer(name='Desktop2', owner='Alice', cpu='Intel i7', gpu='NVIDIA RTX 3080', ram='16GB'),
            Computer(name='Laptop2', owner='Bob', cpu='AMD Ryzen 9', gpu='NVIDIA RTX 3070', ram='32GB'),
            Computer(name='Server2', owner='Admin', cpu='AMD EPYC', gpu='N/A', ram='128GB'),
            Computer(name='Desktop3', owner='Eve', cpu='Intel Core', gpu='NVIDIA GTX 1050', ram='4GB'),
            Computer(name='Laptop3', owner='Charlie', cpu='Intel Core i3', gpu='Integrated', ram='8GB'),
            Computer(name='Server3', owner='Admin', cpu='Intel Xeon', gpu='N/A', ram='256GB'),
            Computer(name='Desktop4', owner='Grace', cpu='AMD Ryzen 5', gpu='AMD Radeon RX 5700', ram='16GB'),
            Computer(name='Laptop4', owner='David', cpu='Intel Core i5', gpu='NVIDIA GTX 1650', ram='16GB'),
            Computer(name='Server4', owner='Admin', cpu='AMD EPYC', gpu='N/A', ram='512GB')
        ]
        db.session.bulk_save_objects(computers)
        db.session.commit()

if __name__ == '__main__':
    connection = True
    while connection:
        try:
            with app.app_context():
                inspector = inspect(db.engine)
                if not inspector.has_table("computer"):
                    db.create_all()
                    add_computers()
                connection = False
        except Exception as e:
            print(e)
        sleep(5)