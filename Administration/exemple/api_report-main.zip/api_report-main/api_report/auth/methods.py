import jwt
from flask import request

def jwt_decode(token):
    with open("./auth/jwt_rsa.pem", mode="rb") as pubkey:
        try:
            data = jwt.decode(token, pubkey.read(), algorithms="RS256")
            return data  # à modifier en fonction du format du token JWT
        except jwt.exceptions.InvalidSignatureError:
            print({"status": "failed", "reason": "invalid signature"})
        except jwt.ExpiredSignatureError:
            print({"status": "failed", "reason": "expired"})
        except jwt.exceptions.DecodeError:
            print({"status": "failed", "reason": "wrong format"})
        except jwt.exceptions.InvalidAlgorithmError:
            print({"status": "failed", "reason": "unexpected algorithm"})

def token_reader():
    if request.cookies.get('token') is not None:
        return jwt_decode(request.cookies.get('token'))
    else :
        try :
            authorization = request.headers['Authorization'].split(" ")
            if authorization[0] == "Bearer":
                return jwt_decode(authorization[1])
            else :
                return False, "Invalid authentication method", None
        except (KeyError, IndexError) :
            return {"username": "Non Connecté","permissions": {'read': [], 'write': []}}

def token_validate_read(token):
    print(token)
    return "servers" in token["permissions"]["read"]

def token_validate_write(token):
    print(token)
    return "servers" in token["permissions"]["write"]