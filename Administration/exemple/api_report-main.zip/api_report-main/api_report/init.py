from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect
from datetime import datetime, date
from time import sleep
import random

app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///report.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://admin:bonjour@10.0.0.2:5432/api'
db = SQLAlchemy()
db.init_app(app)
types = ["Computer", "Server", "License"]


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String, default="UNKNOWN")
    date = db.Column(db.Date, default=datetime.utcnow)
    data = db.Column(db.JSON, default=[{},{},{}])

    def __repr__(self):
        return f"<Report id:{self.id}, type:{self.type}, date:{self.date}, data:{self.data}>"

def add_reports():
    with db.session.no_autoflush:
        reports = [
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"11", "name":"XY"}, {"id":"12", "name":"YZ"}, {"id":"13", "name":"ZW"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"14", "name":"LM"}, {"id":"15", "name":"NO"}, {"id":"16", "name":"PQ"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"17", "name":"RS"}, {"id":"18", "name":"ST"}, {"id":"19", "name":"TU"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"20", "name":"VW"}, {"id":"21", "name":"WX"}, {"id":"22", "name":"YZ"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"23", "name":"AB"}, {"id":"24", "name":"CD"}, {"id":"25", "name":"EF"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"26", "name":"GH"}, {"id":"27", "name":"IJ"}, {"id":"28", "name":"KL"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"29", "name":"MN"}, {"id":"30", "name":"OP"}, {"id":"31", "name":"QR"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"32", "name":"ST"}, {"id":"33", "name":"UV"}, {"id":"34", "name":"WX"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"35", "name":"YZ"}, {"id":"36", "name":"AB"}, {"id":"37", "name":"CD"}]),
            Report(type=random.choice(types), date=date(2024, 4, 1), data=[{"id":"38", "name":"DE"}, {"id":"39", "name":"FG"}, {"id":"40", "name":"HI"}])
        ]
        db.session.bulk_save_objects(reports)
        db.session.commit()


if __name__ == '__main__':
    connection = True
    while connection:
        try:
            with app.app_context():
                inspector = inspect(db.engine)
                if not inspector.has_table("report"):
                    db.create_all()
                    add_reports()
                connection = False
        except Exception as e:
            print(e)
        sleep(5)