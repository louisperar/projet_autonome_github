from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_cors import cross_origin
from sqlalchemy import text, inspect
from flask_sqlalchemy import SQLAlchemy
from functions import querry, delete, update, add
import requests, auth.methods as methods

app = Flask(__name__)
#postgresql://username:password@hostname:port/database_name
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://admin:bonjour@10.0.0.2:5432/api'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///report.db'

db = SQLAlchemy()
db.init_app(app)

port = 5000
limit_request = 50

#########################################
#-------------   API/JSON   ------------#
#########################################

@app.route('/api/report', methods=['POST', 'GET'])
@cross_origin()
def api_report():
    """
    Add a new report or get all reports.

    This function handles two HTTP methods:
        - GET: Returns a tuple containing the report information and the HTTP status code.
            The report information is a list of dictionaries.
            The HTTP status code is an integer.
        - POST: Adds a new report to the database and returns a success message with HTTP status code.

    Returns:
        tuple: A tuple containing the response message and the HTTP status code.
    """
    if request.method == "GET":
        return (querry(db, f"SELECT * FROM report LIMIT {limit_request}")).json, 200
        
    elif request.method == "POST":
        parameters = (querry(db, "SELECT * FROM report LIMIT 1")).json[0].keys()
        data_request = request.json
        print(data_request)
        present = [(element in parameters, element) for element in list(data_request.keys())]
        if len(present) == 0:
            return 'No Argument', 400
        elif all(boolean[0] for boolean in present):
            if add(db, data_request):
                return 'Ressource Add', 200
            else:
                return 'Error During Add', 400
        else:
            print({'message':'Parameter(s) Not Found', 'info': present})
            return jsonify({'message':'Parameter(s) Not Found', 'info': present}), 404
    else:
        return 'Method unauthorized', 405

@app.route('/api/report/<int:report_id>', methods=['GET', 'DELETE', 'PATCH'])
@cross_origin()
def api_rapportid(report_id:int=0):
    """
    Get, delete or update report information by report ID.

    Args:
        report_id (int): The ID of the report.

    Methods:
        GET: Returns a tuple containing the report information and the HTTP status code.
            The report information is a list of dictionaries.
            The HTTP status code is an integer.
        DELETE: Deletes the report with the given ID and returns a success message with HTTP status code.
        PATCH: Updates the report with the given ID and returns a success message with HTTP status code.

    Returns:
        tuple: A tuple containing the response message and the HTTP status code.
    """
    if request.method == 'GET':
        if int(report_id) == 0:
            return (querry(db, f"SELECT * FROM report LIMIT {limit_request}")).json, 200
        else:
            data = querry(db, f'SELECT * FROM report WHERE "id" = {report_id} LIMIT {limit_request}')
            if len(data.json) == 0:
                return 'Ressource Not Found', 400
            else:
                return data, 200
        
    elif request.method == 'DELETE':
        if report_id == 0:
            return 'Unable to delete everything', 403
        if delete(db, report_id):
            return 'Ressource Deleted', 200
        else:
            return 'Error During Deletion', 400  
        
    elif request.method == 'PATCH':
        if report_id == 0:
            return 'Unable to delete everything', 403
        parameters = (querry(db, "SELECT * FROM report LIMIT 1")).json[0].keys()
        data_request = request.json
        present = [(element in parameters, element) for element in list(data_request.keys())]
        if len(present) == 0:
            return 'No Argument', 400
        elif all(boolean[0] for boolean in present):
            condition = ", ".join([ f"`{key}` = '{elt}'" for key, elt in data_request.items() if elt != ""])
            if update(db, condition, report_id):
                return 'Ressource Update', 200
            else:
                return 'Error During Update', 400
        else:
            return jsonify({'message':'Parameter(s) Not Found', 'info': present}), 404
    else:
        return 'Method unauthorized', 405

@app.route("/api/report/findby", methods=["GET"])
@cross_origin()
def api_get_report_filtered():
    """
    Get report information based on filter parameters.

    Args:
        request.args (dict): The filter parameters.

    Returns:
        tuple: A tuple containing the report information and the HTTP status code.
            The report information is a list of dictionaries.
            The HTTP status code is an integer.
    """
    if request.method == "GET":
        parameters = (querry(db, "SELECT * FROM report LIMIT 1")).json[0].keys()
        data_request = request.args
        present = [(element in parameters, element) for element in list(data_request.keys())]
        if len(present) == 0:
            return 'No Argument', 400
        elif all(boolean[0] for boolean in present):
            condition = " AND ".join([f"{key} {'=' if key == 'date' else 'ILIKE'} '%{elt}%'" for key, elt in data_request.items() if elt != ""])
            if len(condition) > 0 :
                data = querry(db, f"SELECT * FROM report WHERE {condition} LIMIT {limit_request}").json
                if len(data) == 0:
                    return 'Ressource Not Found', 440
                else:
                    return data, 200
            else:
                return 'Empty Parameter', 440
        else:
            return jsonify({'message':'Parameter(s) Not Found', 'info': present}), 404
    else:
        return 'Method unauthorized', 405 
    
#########################################
#-------------   API/HTML   ------------#
#########################################

navbar_html = [ {"id":"1", "name":"Rechercher par ID", "url":"/report/search"},
                {"id":"2", "name":"Recherche Avancée", "url":"/report/findBy"},
                {"id":"3", "name":"Suppression", "url":"/report/delete"},
                {"id":"4", "name":"Ajout", "url":"/report/add"},
                {"id":"5", "name":"Visualisation", "url":"/report/show"}]

# Route d'accueil
@app.route('/')
def report():
    token = methods.token_reader()
    return render_template( "index.html", 
                            navbar=navbar_html,
                            user_name=token["username"])

@app.route("/report/findBy", methods=["GET"])
def search_advanced_report():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_read(token):
        return render_template( "search_advanced.html", 
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html", 
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/report/delete", methods=["GET"])
def delete_report():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_write(token):
        return render_template( "suppression.html", 
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html", 
                        navbar=navbar_html,
                        user_name=token["username"])
    
@app.route("/report/add", methods=["GET"])
def add_report():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_write(token):
        return render_template( "add.html", 
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html", 
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/report/search", methods=["GET"])
def search_report():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_read(token):
        return render_template( "search.html", 
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html", 
                        navbar=navbar_html,
                        user_name=token["username"])

@app.route("/report/show", methods=["GET"])
def show_report():
    token = methods.token_reader()
    token = {'Id': '1234', 'username': 'test', 'permissions': {'read': ["servers"], 'write': ["servers"]}, 'iat': 1711613127, 'exp': 1712822727}
    if methods.token_validate_read(token):
        return render_template( "show.html", 
                                navbar=navbar_html,
                                accept=True,
                                list=False,
                                user_name=token["username"]
                                ), 200
    else:
        return render_template( "no_permissions.html", 
                        navbar=navbar_html,
                        user_name=token["username"])

if __name__ == '__main__':
    app.run(debug=True)