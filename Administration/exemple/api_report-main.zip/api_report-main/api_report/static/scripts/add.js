const origine = window.location.origin;

async function displayComputerList() {
    try {
        const response = await fetch(origine + '/api/report/0');
        const data = await response.json();
        const computerList = document.getElementById('computer-list');
        computerList.innerHTML = '';
        data.forEach(computer => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${computer.id}</td>
                <td>${computer.type}</td>
                <td>${computer.date}</td>`;
            computerList.appendChild(tr);
        });
        document.getElementById('addComputerForm').reset();
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

document.getElementById('addComputerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const jsonData = {};
    let currentDate = new Date();
    let year = currentDate.getFullYear();
    let month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    let day = currentDate.getDate().toString().padStart(2, '0');
    let formattedDate = `${year}-${month}-${day}`;
    formData.forEach((value, key) => {
        jsonData[key] = value;
    });
    jsonData["date"] = formattedDate
    console.log(jsonData)
    try {
        const url_api = {
            "computer" : "http://192.168.1.39:8000/api/computer/0"
            /*"computer" : "http://localhost:7000/api/computer/0"*/
        }
        var data = await fetch(url_api[jsonData["data"]]);
        data = await data.json();
        jsonData["data"] = data;
        console.log(jsonData)
        const response = await fetch(origine + '/api/report', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(jsonData)
        });
        console.log(response.ok)
        if (response.ok) {
            document.getElementById('message').innerHTML = "Ordinateur ajouté avec succès !";
            document.getElementById('message').className = "alert alert-success";
            await displayComputerList();
        } else {
            document.getElementById('message').innerHTML = "Problème lors de l'ajout.";
            document.getElementById('message').className = "alert alert-danger";
            console.error('Error adding report:', response.statusText);
        }
    } catch (error) {
        document.getElementById('message').innerHTML = "Problème lors de l'ajout.";
        document.getElementById('message').className = "alert alert-danger";
        console.error('Error adding report:', error);
    }
});

document.getElementById('refresh-button').addEventListener('click', async function() {
    await displayComputerList();
});

displayComputerList();