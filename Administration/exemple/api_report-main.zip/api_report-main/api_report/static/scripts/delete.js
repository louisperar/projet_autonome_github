const origine = window.location.origin;

async function displayComputerList() {
    try {
        const response = await fetch(origine + '/api/report');
        const data = await response.json();
        const computerList = document.getElementById('computer-list');
        computerList.innerHTML = '';
        data.forEach(computer => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
            <td>${computer.id}</td>
            <td>${computer.type}</td>
            <td>${computer.date}</td>
            `;
            computerList.appendChild(tr);
        });
        document.getElementById('deleteComputerForm').reset();
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

document.getElementById('deleteComputerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const jsonData = {};
    formData.forEach((value, key) => {
        jsonData[key] = value;
    });
    console.log(jsonData["id"])
    try {
        const response = await fetch(origine + '/api/report/' + jsonData["id"], {
            method: 'DELETE'
        });
        console.log(response.ok)
        if (response.ok) {
            document.getElementById('message').innerHTML = "Ordinateur supprimé avec succès !";
            document.getElementById('message').className = "alert alert-success";
            await displayComputerList();
        } else {
            document.getElementById('message').innerHTML = "Problème lors de la suppression.";
            document.getElementById('message').className = "alert alert-danger";
            console.error('Error deleting computer:', response.statusText);
        }
    } catch (error) {
        document.getElementById('message').innerHTML = "Problème lors de la suppression.";
        document.getElementById('message').className = "alert alert-danger";
        console.error('Error deleting computer:', error);
    }
});

document.getElementById('refresh-button').addEventListener('click', async function() {
    await displayComputerList();
});

displayComputerList();