const origine = window.location.origin;

async function displayComputerList(id_computer) {
    try {
        if (id_computer == 0) {
            const response = await fetch(origine + '/api/report/' + id_computer);
            const data = await response.json();

            const computerListHeader = document.getElementById('computer-header');
            computerListHeader.innerHTML = '';
            const firstComputer = data[0];
            const tr = document.createElement('tr');
            Object.keys(firstComputer).forEach(key => {
                if ( key != "data" ){
                    const th = document.createElement('th');
                    th.textContent = key;
                    tr.appendChild(th);
                }
            });
            computerListHeader.appendChild(tr);

            const computerList = document.getElementById('computer-list');
            computerList.innerHTML = '';
            data.forEach(computer => {
                const tr = document.createElement('tr');
                Object.keys(computer).forEach(key => {
                    if ( key != "data" ) {
                        const td = document.createElement('td');
                        td.textContent = computer[key];
                        tr.appendChild(td);
                    }
                });
                computerList.appendChild(tr);
            });
            document.getElementById('addComputerForm').reset();
        }else{
            const response = await fetch(origine + '/api/report/' + id_computer);
            const data = await response.json();
            
            const computerListHeader = document.getElementById('computer-header');
            computerListHeader.innerHTML = '';
            const firstComputer = data[0]["data"];
            
            const trHeader = document.createElement('tr');
            Object.keys(firstComputer[0]).forEach(key => {
                if (key != "data"){
                    const th = document.createElement('th');
                    th.textContent = key;
                    trHeader.appendChild(th);
                }
            });
            computerListHeader.appendChild(trHeader);
            
            const computerList = document.getElementById('computer-list');
            computerList.innerHTML = '';
            firstComputer.forEach(computer => {
                const tr = document.createElement('tr');
                
                Object.keys(computer).forEach(key => {
                    if (key != "data") {
                        const td = document.createElement('td');
                        td.textContent = computer[key];
                        tr.appendChild(td);
                    }
                });
                computerList.appendChild(tr);
            });
            document.getElementById('addComputerForm').reset();
        }
        
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

document.getElementById('addComputerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const jsonData = {};
    formData.forEach((value, key) => {
        jsonData[key] = value;
    });
    try {
        const response = await fetch(origine + '/api/report/' + jsonData["id"], {
            method: 'GET'
        });
        console.log(response.ok)
        if (response.ok) {
            document.getElementById('message').innerHTML = "Recherche efféctué avec succès !";
            document.getElementById('message').className = "alert alert-success";
            await displayComputerList(jsonData["id"]);
        } else {
            document.getElementById('message').innerHTML = "Problème lors de la recherche.";
            document.getElementById('message').className = "alert alert-danger";
            console.error('Error computer:', response.statusText);
        }
    } catch (error) {
        document.getElementById('message').innerHTML = "Problème lors de la recherche.";
        document.getElementById('message').className = "alert alert-danger";
        console.error('Error computer:', error);
    }
});

document.getElementById('refresh-button').addEventListener('click', async function() {
    await displayComputerList(0);
});

displayComputerList(0);