# API Rapport

## Objectifs
L'API de gestion des rapport permet d'obtenir des rappords sur les actifs et licences de l'entreprise. Il est également possible d'obtenir un rapport spécifique (avec son ID) et d'appliquer des filtres pour obtenir des informations spécifiques sur un ou plusieurs rapports. Il est possible pour les administrateurs d'ajouter ou supprimer un rapport. 
**!!! Ce service est accessible seulement par les administrateurs !!!**

## Utilisateurs

### Utilisateur Administrateur
- **GET:** Accéder à toutes les rapports.
- **DELETE:** Supprimer un rapport existant.
- **POST:** Générer un nouveau rapport.

## Informations des rapports

### Administrateur
- id
- type
- date
- data

## Endpoints

- `./api/report` : 
  - |GET| -> Renvoie une liste de rapport.
  - |POST| -> Génère un rapport.
- `./api/report/<int:report_id>` :
  - |GET| -> Détails d'un rapport (avec liste des rapport si ID non renseigné ou = 0).
  - |DELETE| -> Supprime un rapport.
  - |PATCH| -> Modifie un rapport.
- `./api/report/findby` -> |GET| -> Recherche par filtre.

Comme vu précédemment nous avons pour chaque méthode une page HTML lié. Donc chaque lien ci-dessous est une page d'affichage donc une requête |GET|

- `./` -> Permet de savoir si le service est en ligne en affichant le menu.
- `./report/findBy` -> |GET| -> Nous envoies sur une page qui a les mêmes fonctionnalités que la page search la différence est que l'on peut filtrer par tous les paramètres autre que l'ID. (requête lié `./api/report/findby` méthode |GET|)
- `./report/delete` -> |GET| -> Renvoie une page où l'on rentre l'ID du rapport que l'on veut supprimé. Utilisable seulement par les administrateurs. (requête lié `./api/report/<int:report_id>` méthode |DELETE|)
- `./computers/search` -> |GET| -> Nous affiche une page sur laquelle on peut faire des recherches par ID et seulement ID. Elle nous affiche de base une liste de rapport avec toutes les informatins de celui-ci. (requête lié `./api/report/<int:report_id>` méthode |GET|)
- `./report/show` -> |GET| -> Permet de voir les données d'un rapport choisi