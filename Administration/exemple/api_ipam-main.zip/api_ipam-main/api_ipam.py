from flask import Flask, request, current_app, abort, jsonify, redirect, render_template
import python_sql as ps
import jwt
import ipcalc

api_ipam = Flask(__name__)
PATH = r"/var/lib/kirbi/shared/"

def videur():
    token = request.cookies.get('token')
    if not token :
        try:
            authorization = request.headers['Authorization'].split(" ")
            #ps.log(authorization)
            if authorization[0] == "Bearer":
                token = authorization[1]
            else:
                return ""
        except:
            return ""
    with open(PATH+r"jwt_rsa.pem", mode="rb") as pub_key:
        try:
            data = jwt.decode(token, pub_key.read(), algorithms="RS256")
        except:
            return ""
    return data

def videur_2():
    token = """eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJJZCI6IjEyMzQiLCJ1c2VybmFtZSI6InRlc3QiLCJwZXJtaXNzaW9ucyI6eyJyZWFkIjpbXSwid3JpdGUiOltdfSwiaWF0IjoxNzExNjEzMTI3LCJleHAiOjE3MTI4MjI3Mjd9.F8wgnngnRcXShEcbfwq5KRXXn45pfLQQhBSWwU4r5eQMe-5eATIYYFTWYgyXqXLDkx_PsCv3hbKx4pEqWmbkVR9C6lRNjBmYwvmNgB0gL-veQNDFZRLJEhcDmliZFYEJ8hS1Byb1jWWp52cikY9ot5IOmeIWFOnbKGs9LK_SRzr_uiQ8wBVKXKnoIDPwDtIKcNCQA6DHO_tpsf6De9xjLJELutwQ4nV6X80RIA-A0oInb4-yjL1hQWq2s_g5hsISMpW2yuwm3F-Q7gKE0xqkKAMO5XNuia_R5myoVHFeKcdZIYO-bkViyk8-cJmMVdp-pCaRrvVU5BH36fM1GvLoL6fNxPpc55h8vcLHNDf_SHwB6Wi-XiMaMG0vMJSs_tDqycG-G33CCcCIpYM9t10kpWregV9r76Milket3VrsAk_SbZ4g8Dqhr8BXeaJ2uyW7ElYKXw_PBoj8yj6qRKYQ33iVF3PAw6cGlWhIwmN2Y90UNi-8U0osLX3Z-LNtDMbqeipoPYLaGS6RHeGAFbot45CZW36s-RiK0TsDhoAw7G_HEAnoVOY0W8EIoLvadJhy7qbYipK_6Qz_jjj4FAI5i3RBU16A2HA5nFPRcPec_YJzlItimMn67wc6e3zHdTZCAH6hhZRL-LjKwasLzLkS0rPBUCkPSNIwbSmv8rlZI3U"""
    with open(PATH+r"jwt_rsa.pem", mode="rb") as pub_key:
            try:
                    data = jwt.decode(token, pub_key.read(), algorithms="RS256")
            except:
                    return ""
    return data

#Group
# Code fait !
@api_ipam.route("/group/", methods = ['POST'])
def slash_group():
    data = videur()
    if not data:
        return "", 400
    try:
        if request.method == 'POST':
            succes = ps.put('ipam','group', request.get_json())
            return ("",200) if succes else ("", 400)
        """
        Code si jamais il y avait un GET /group/
        groupes = ps.get('ipam',['group'])
        return jsonify(groupes)
        """
    except:
        return "", 400

# Code fait !
@api_ipam.route("/group/<groupId>", methods = ['GET','DELETE','PATCH'])
def slash_group_groupId(groupId):
    data = videur()
    if not data:
        return "", 400
    try:
        groupId = int(groupId)
    except:
        return "", 400
    groupes = ps.get('ipam',['group'])
    if groupId not in [groupe[0] for groupe in groupes]:
        return "", 404
    if request.method == 'GET':
        groupes = ps.get('ipam',['group'], 'id', groupId)
        return jsonify(groupes), 200
    if request.method == 'DELETE':
        succes = ps.delete('ipam','group', groupId)
    if request.method == 'PATCH':
        succes = ps.delete('ipam','group', groupId) and ps.put('ipam','group', request.get_json())
    return ("", 200) if succes else ("", 400)

# Code fait !
@api_ipam.route("/group/findByName", methods = ['GET'])
def slash_group_findByName():
    data = videur()
    if not data:
        return "", 400
    name = request.args.get("name")
    groupes = ps.get('ipam',['group'], 'name', name)
    return (jsonify(groupes), 200) if groupes else ("", 400)

# Code fait !
@api_ipam.route("/group/findByParent", methods = ['GET'])
def slash_group_findByParent():
    data = videur()
    if not data:
        return "", 400
    parent_id = request.args.get("parent")
    groupes = ps.get('ipam',['group'], 'parent_id', parent_id)
    return (jsonify(groupes), 200) if groupes else ("", 400)

# Code fait !
@api_ipam.route("/group/findByChild", methods = ['GET'])
def slash_group_findByChild():
    data = videur()
    if not data:
        return "", 400
    child_id = request.args.get("child")
    groupes = ps.get('ipam',['group'])
    groupes = [groupe for groupe in groupes if child_id in str(groupe[3])]
    return (jsonify(groupes), 200) if groupes else ("", 400)



#Address
# Code fait !
@api_ipam.route("/address/", methods = ['POST'])
def slash_address():
    data = videur()
    if not data:
        return "", 400
    try:
        succes = ps.put('ipam','address',request.get_json())
        return ("", 200) if succes else ("", 400)
    except:
        return "", 400

# Code fait !
@api_ipam.route("/address/<addressId>", methods = ['GET','DELETE','PATCH'])
def slash_address_addressId(addressId):
    data = videur()
    if not data:
        return "", 400
    try:
        addressId = int(addressId)
    except:
        return "", 400
    adresses = ps.get('ipam', ['address'])
    if addressId not in [adresse[0] for adresse in adresses]:
        return "", 404
    if request.method == 'GET':
        adresses = ps.get('ipam', ['address'], 'id', addressId)
        return jsonify(adresses), 200
    if request.method == 'DELETE':
        succes = ps.delete('ipam', 'address', addressId)
    if request.method == 'PATCH':
        succes = ps.delete('ipam', 'address', addressId) and ps.put('ipam', 'address', request.get_json())
    return ("", 200) if succes else ("", 400)

# Code fait !
@api_ipam.route("/address/findByAddress", methods = ['GET'])
def slash_address_findByAddress():
    data = videur()
    if not data:
        return "", 400
    address = request.args.get("address")
    adresses = ps.get('ipam', ['address'], 'address', address)
    return (jsonify(adresses), 200) if adresses else ("", 400)



#Subnet
# Code à tester
@api_ipam.route("/subnet/", methods = ['POST'])
def slash_subnet():
    data = videur()
    if not data:
        return "", 400
    try:
        succes = ps.put('ipam', 'subnet', request.get_json())
        return ("", 200) if succes else ("", 400)
    except:
        return "", 400

# Code à tester
@api_ipam.route("/subnet/<subnetId>", methods = ['GET','DELETE', 'PATCH'])
def slash_subnet_subnetId(subnetId):
    data = videur()
    if not data:
        return "", 400
    try:
        subnetId = int(subnetId)
    except:
        return "", 400
    subnets = ps.get('ipam', ['subnet'])
    if subnetId not in [sub[0] for sub in subnets]:
        return "", 404
    if request.method == 'GET':
        subnets = ps.get('ipam', ['subnet'], id, subnetId)
        return jsonify(subnets), 200
    if request.method == 'DELETE':
        succes = ps.delete('ipam', 'subnet', subnetId)
    if request.method == 'PATCH':
        succes = ps.delete('ipam', 'subnet', subnetId) and ps.put('ipam', 'subnet', request.get_json())
    return ("", 200) if succes else ("", 400)

# Code à faire, dont il faut rédiger un test, dont le test ne fonctionne pas
@api_ipam.route("/subnet/findByMask", methods = ['GET'])
def slash_subnet_findByMask():
    data = videur()
    if not data:
        return "", 400
    try:
        mask = request.args.get("mask")
        subnets = ps.get('ipam',['subnet'], 'mask', mask)
        return (jsonify(subnets), 200) if subnets[0] else ("", 400)
    except:
        return "", 400

# Code à faire, dont il faut rédiger un test, dont le test ne fonctionne pas
@api_ipam.route("/subnet/findByVlanid", methods = ['GET'])
def slash_subnet_findByVlanid():
    data = videur()
    if not data:
        return "", 400
    vlan_id = request.args.get("vlan")
    subnets = ps.get('ipam',['subnet'], 'group_id', vlan_id)
    return (jsonify(subnets), 200) if subnets else ("", 400)

# Code à faire, dont il faut rédiger un test, dont le test ne fonctionne pas
@api_ipam.route("/subnet/findByAddress", methods = ['GET'])
def slash_subnet_findByAddress():
    data = videur()
    if not data:
        return "", 400
    try:
        addresse = request.args.get("address")
        subnets = [sub for sub in ps.get('ipam', ['subnet']) if addresse in ipcalc.Network(sub[1], sub[4])]
        if not subnets:
            return "", 400
        return jsonify(subnets[0]), 200
    except:
        return "", 400


#Interface Web

@api_ipam.route("/")
def index():
    return redirect('/ipam/')

@api_ipam.route("/ipam/", methods=['GET'])
def menu():
    data = videur()
    if not data:
        return "", 400
    group_id = request.args.get("group") if request.args.get("group") else 0
    can_write, groupes = get_group(int(group_id))
    cles_subnet = ['id','first_address','last_address', 'desc','mask','r_r','w_r','g_id']
    subnets = ps.get('ipam',['subnet'], 'group_id',group_id)
    subnets = [{key:value for key,value in zip(cles_subnet, cont)} for cont in subnets]
    ps.log(groupes)
    return render_template('ipam.html', groupes=groupes, subnets=subnets, can_write=can_write, id=int(group_id))

def get_group(id:int) -> tuple[bool, list[tuple], list[tuple]]:
    roles = () #appel API Barnab
    roles = {"_":"superadmin"}
    cles_groupe = ['id','name','parent_id', 'content_id','r_r','w_r', 'can_write']
    if not roles:
        return [], []
    groupes = ps.get('ipam',['group'])
    groupes = {groupe[0]:{key:value for key,value in zip(cles_groupe, groupe + (True,))} for groupe in groupes}
    if [x for x in roles.values()] == ['superadmin']:
        return True, groupes.values()
    gp_city = ""
    if id:
        gp_city = groupes[id]['name']
    groupes = []
    can_write = False
    for city, role in roles.items():
        if city == gp_city and id:
                can_write = role=='dsi_local'
        groupes += [groupe + (role=='dsi_local',) for groupe in ps.get('ipam',['group'], 'name', city)]
    groupes = [{key:value for key,value in zip(cles_groupe, groupe)} for groupe in groupes]
    return can_write, groupes

@api_ipam.route('/edit/group', methods = ['GET'])
def edit_group():
    data = videur()
    if not data:
        return "", 400
    cles_groupe = ['id','name','parent_id', 'content_id','r_r','w_r']
    id = request.args.get("id")
    groupe = ps.get('ipam',['group'], 'id', id)
    groupe = {key:value for key,value in zip(cles_groupe, groupe[0])} 
    groupes = ps.get('ipam',['group'])
    groupes = [{k:v for k,v in zip(cles_groupe, groupe)} for groupe in groupes]
    return render_template('edit_group.html', groupe=groupe, groupes=groupes)

@api_ipam.route('/edit/subnet', methods = ['GET'])
def edit_subnet():
    data = videur()
    if not data:
        return "", 400
    cles_groupe = ['id','name','parent_id', 'content_id','r_r','w_r']
    cles_subnet = ['id','first_addr','last_addr','desc','mask','r_r','w_r','gp_id']
    id = request.args.get("id")
    subnet = ps.get('ipam',['subnet'], 'id', id)
    subnet = {key:value for key,value in zip(cles_subnet, subnet[0])} 
    groupes = ps.get('ipam',['group'])
    groupes = [{k:v for k,v in zip(cles_groupe, groupe)} for groupe in groupes]
    return render_template('edit_subnet.html', subnet=subnet, groupes=groupes)

@api_ipam.route('/new/group/', methods = ['GET'])
def new_group():
    data = videur()
    cles_groupe = ['id','name','parent_id', 'content_id','r_r','w_r']
    if not data:
        return "", 400
    groupes = ps.get('ipam',['group'])
    groupes = [{k:v for k,v in zip(cles_groupe, groupe)} for groupe in groupes]
    return render_template('new_group.html', groupes=groupes)

@api_ipam.route('/new/subnet/', methods = ['GET'])
def new_subnet():
    data = videur()
    cles_groupe = ['id','name','parent_id', 'content_id','r_r','w_r']
    if not data:
        return "", 400
    groupes = ps.get('ipam',['group'])
    groupes = [{k:v for k,v in zip(cles_groupe, groupe)} for groupe in groupes]
    return render_template('new_subnet.html', groupes=groupes)

@api_ipam.route('/action_form/groupe/<int:id>', methods = ['POST'])
def action_form_group(id:int):
    data = videur()
    if not data:
        return "", 400
    if id == 0:
        id = request.form.get('id')
    arguments = {'id': id,
                 'name': request.form.get('name'),
                 'parent_id': request.form.get('parent_id'),
                 'content_ids':[0],
                 'r_r':request.form.getlist('r_r')if request.form.getlist('r_r') else ['user'],
                 'w_r':request.form.getlist('w_r')if request.form.getlist('w_r') else ['user']}
    ps.delete('ipam','group',id)
    ps.put('ipam','group', arguments)
    return redirect('/ipam')

@api_ipam.route('/action_form/subnet/<int:id>', methods = ['POST'])
def action_form_subnet(id:int):
    data = videur()
    if not data:
        return "", 400
    arguments = {'id':id,
                 'first_addr': request.form.get('first_addr'),
                 'last_addr': request.form.get('last_addr'),
                 'desc': request.form.get('desc'),
                 'mask': request.form.get('mask'),
                 'r_r':request.form.getlist('r_r') if request.form.getlist('r_r') else ['user'],
                 'w_r':request.form.getlist('w_r') if request.form.getlist('w_r') else ['user'],
                 'gp_id': request.form.get('gp_id')}
    ps.delete('ipam','subnet',id)
    succes = ps.put('ipam','subnet', arguments)
    return redirect('/ipam')

@api_ipam.route('/delete/group')
def delete_group():
    data = videur()
    if not data:
        return "", 400
    id = request.args.get('id')
    ps.delete('ipam','group',id)
    return redirect('/ipam')

@api_ipam.route('/delete/subnet')
def delete_subnet():
    data = videur()
    if not data:
        return "", 400
    id = request.args.get('id')
    ps.delete('ipam','subnet',id)
    return redirect('/ipam')

if __name__ == "__main__":
    ps.create_database('ipam')
    ps.create_table('ipam', 'group')
    ps.create_table('ipam', 'subnet')
    ps.create_table('ipam', 'address')
    ps.add_column('ipam','group','name',str)
    ps.add_column('ipam','group','parent_id',int)
    ps.add_column('ipam','group','content_id',list[int])
    ps.add_column('ipam','group','r_r',list[str])
    ps.add_column('ipam','group','w_r',list[str])
    ps.add_column('ipam','subnet','first_addr',str)
    ps.add_column('ipam','subnet','first_addr',str)
    ps.add_column('ipam','subnet','desc',str)
    ps.add_column('ipam','subnet','mask',int)
    ps.add_column('ipam','subnet','r_r',list[str])
    ps.add_column('ipam','subnet','w_r',list[str])
    ps.add_column('ipam','subnet','g_id',int)
    ps.add_column('ipam','address','address',str)
    ps.add_column('ipam','address','mask',int)
    ps.add_column('ipam','address','online',bool)
    ps.add_column('ipam','address','attribuated',bool)
    api_ipam.run(debug=True)
