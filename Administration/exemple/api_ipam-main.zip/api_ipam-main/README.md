# api_ipam
## IMPORTANT !
### Pour la construction des Tables de données !!
### Bien penser à mettre comme primary_key "id" (et rien d'autre, juste "id")
### Bien penser à mettre comme foreign_key "{table_etrangere}_key" ex : "group_id" ou "subnet_id"


### Arbo :

- /FA_2 
    - Docker-compose.yaml
    - /app_api_licenses
        - Dockerfile
        - api_license.py (flask à exec dans dockerfile)
        - /templates
            - (jinja)
        - python_sql_licenses.py
    - /app_api_ipam
        - Dockerfile
        - api_ipam.py
        - /templates
            - (jinja)
        - python_sql_ipam.py
