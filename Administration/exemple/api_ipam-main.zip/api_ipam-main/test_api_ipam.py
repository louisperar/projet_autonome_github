import requests
import json
from requests.structures import CaseInsensitiveDict
import traceback

def test_patch(path:str='/', data:dict[str, str]= {}) -> tuple[str, dict]:
    try:
        headers = CaseInsensitiveDict()
        headers['Content-Type'] = 'application/json'
        test = requests.patch( f'http://localhost:5000{path}', headers=headers, data=json.dumps(data))
    except:
        traceback.print_exc()
        return 0, {}
    return test.status_code, {}

def test_get(path:str='/') -> tuple[str, dict]:
    try:
        headers = CaseInsensitiveDict()
        headers['Content-Type'] = 'application/json'
        test = requests.get( f'http://localhost:5000{path}', headers=headers)
    except:
        traceback.print_exc()
        return 0, {}
    if test.status_code == 200:
        return test.status_code, json.loads(test.text)
    return test.status_code, {}

def test_delete(path:str='/', id:int=0) -> tuple[str, dict]:
    try:
        headers = CaseInsensitiveDict()
        headers['Content-Type'] = 'application/json'
        test = requests.delete( f'http://localhost:5000{path}{id}', headers=headers)
    except:
        traceback.print_exc()
        return 0, {}
    return test.status_code, {}

def test_post(path:str='/', data:dict[str, str]= {}) -> tuple[str, dict]:
    try:
        headers = CaseInsensitiveDict()
        headers['Content-Type'] = 'application/json'
        test = requests.post( f'http://localhost:5000{path}', headers=headers, data=json.dumps(data))
    except:
        traceback.print_exc()
        return 0, {}
    return test.status_code, {}


##### Tests Group
def test_group():
    # POST /group
    for id, code in zip([2,'bob'],[200,400]):
        data =  {'id':id,
                'name':'Vannes',
                'parent_id':1,
                'content_ids':[1,2,3,4],
                'reading_roles':['dsi_local', 'superadmin'],
                'writing_roles':['superadmin']}
        test = test_post('/group/', data)   
        print(f'\n[{test[0]}] {test[0] == code} POST /group/{id} {data}')

    # PATCH /group/{groupId} cas 200, 400 & 404
    for id, code in zip([2,'bob',306], [200, 400, 404]):
        test = test_patch(f'/group/{id}', {'id':id,
                                              'name':'Vannes',
                                              'parent_id':1,
                                              'content_ids':[5,6,7,8],
                                              'reading_roles':['dsi_local', 'superadmin'],
                                              'writing_roles':['superadmin']})
        print(f'\n[{test[0]}] {test[0] == code} PATCH /group/{id} {{data}}')

    # GET /group/{groupId} cas 200, 400 & 404
    for id, code in zip([2,'bob',306], [200, 400, 404]):
        test = test_get(f'/group/{id}')
        print(f'\n[{test[0]}] {test[0] == code} GET /group/{id} : {test[1]}')

    # GET /group/findByName
    for nom, code in zip(['Vannes','nomintrouvable'], [200, 400]):
        test = test_get(f'/group/findByName?name={nom}')
        print(f'\n[{test[0]}] {test[0] == code} GET /group/findByName={nom} : {test[1]}')

    # GET /group/findByParent
    for parent_id, code in zip([1,788], [200,400]):
        test = test_get(f'/group/findByParent?parent={parent_id}')
        print(f'\n[{test[0]}] {test[0] == code} GET /group/findByParent?parent={parent_id} : {test[1]}')

    # GET /group/findByChild
    for child_id, code in zip([1,788], [200,400]):
        test = test_get(f'/group/findByChild?child={child_id}')
        print(f'\n[{test[0]}] {test[0] == code} GET /group/findByChild?child={child_id} : {test[1]}')

    # DELETE /group/{groupId}
    for id, code in zip([2,'bob', 789], [200, 400, 404]):
        test = test_delete('/group/', id)
        print(f'\n[{test[0]}] {test[0] == code} DELETE /group/{id}')

##### Tests Address
def test_address():
    # POST /address
    for id, code in zip([2,'bob'],[200,400]):
        data = {'id':id,
                'address':'10.0.0.1',
                'mask':25,
                'online':False,
                'attribuated':True}
        test = test_post('/address/', data)
        print(f'\n[{test[0]}] {test[0] == code} POST /address/ {data}')

    # PATCH /address/{addressId}
    for id, code in zip([2,'bob',306], [200, 400, 404]):
        test = test_patch(f'/address/{id}', {'id':id,
                                            'address':'10.0.0.2',
                                            'mask':24,
                                            'online':True,
                                            'attribuated':True})
        print(f'\n[{test[0]}] {test[0] == code} PATCH /address/{id} {{data}}')

    # GET /address/findByAddress
    for addresse, code in zip(['10.0.0.2','addresseintrouvable'], [200, 400]):
        test = test_get(f'/address/findByAddress?address={addresse}')
        print(f'\n[{test[0]}] {test[0] == code} GET /address/findByAddress?address={addresse} : {test[1]}')

    # GET /address/{addressId}
    for id, code in zip([2,'bob',306], [200, 400, 404]):
        test = test_get(f'/address/{id}')
        print(f'\n[{test[0]}] {test[0] == code} GET /address/{id} : {test[1]}')

    # DELETE /address/{addressId}
    for id, code in zip([2,'bob', 789], [200, 400, 404]):
        test = test_delete('/address/', id)
        print(f'\n[{test[0]}] {test[0] == code} DELETE /address/{id}')

##### Tests Subnet
def test_subnet():
    # POST /subnet
    for id, code in zip([2,'bob'],[200,400]):
        data = {'id':id,
                '1st_address':'10.0.0.0',
                'last_address':'10.0.0.4',
                'description':"Range Wifi de Brest",
                'mask':30,
                'reading_roles':["dsi_local","superadmin"],
                'writing_roles':["superadmin"],
                'group_id':3}
        test = test_post('/subnet/', data)
        print(f'\n[{test[0]}] {test[0] == code} POST /subnet/{id} {data}')

    # PATCH /subnet
    for id, code in zip([2,'bob',306], [200, 400, 404]):
        test = test_patch(f'/subnet/{id}',{'id':id,
                                           '1st_address':'10.0.0.0',
                                           'last_address':'10.0.0.4',
                                           'description':"Range Wifi de Vannes",
                                           'mask':30,
                                           'reading_roles':["dsi_local","superadmin"],
                                           'writing_roles':["superadmin"],
                                           'group_id':3})
        print(f'\n[{test[0]}] {test[0] == code} PATCH /subnet/{id} {{data}}')

    # GET /subnet/findByAddress
    for address, code in zip(["10.0.0.2",'addresseintrouvable'], [200,400]):
        test = test_get(f'/subnet/findByAddress?address={address}')
        print(f'\n[{test[0]}] {test[0] == code} GET /subnet/findByAddress?address={address} : {test[1]}')

    # GET /subnet/findByMask
    for mask, code in zip([32,'bob'], [200,400]):
        test = test_get(f'/subnet/findByMask?mask={mask}')
        print(f'\n[{test[0]}] {test[0] == code} GET /subnet/findByMask?mask={mask} : {test[1]}')

    # GET /subnet/findByVlanid
    for vlan_id, code in zip([1,788], [200,400]):
        test = test_get(f'/subnet/findByVlanid?vlan={vlan_id}')
        print(f'\n[{test[0]}] {test[0] == code} GET /subnet/findByAddress?vlanid={vlan_id} : {test[1]}')

    # GET /subnet/{subnetId}
    for id, code in zip([2,'bob',306], [200, 400, 404]):
        test = test_get(f'/subnet/{id}')
        print(f'\n[{test[0]}] {test[0] == code} GET /subnet/{id} : {test[1]}')

    # DELETE /subnet/{subnetId}
    for id, code in zip([2,'bob', 789], [200, 400, 404]):
        test = test_delete('/subnet/', id)
        print(f'\n[{test[0]}] {test[0] == code} DELETE /subnet/{id}')

if __name__ == '__main__':
    #print("Test Address".center(34, '='))
    #test_address()
    #print("Test Group".center(34, '='))
    #test_group()
    print("Test Subnet".center(34, '='))
    test_subnet()