from flask import Flask, jsonify, request, render_template
from pathlib import Path
import psycopg2 as ps
import jwt
from pathlib import Path
import os

try:
    conn = ps.connect(
        database = os.getenv("DB_PROJECT", "postgres"),
        user =  os.getenv("DB_USER", "postgres"),
        password =  os.getenv("DB_PASSWORD", "bonjour"),
        host =  os.getenv("DB_HOST", "localhost"),
        port =  os.getenv("DB_PORT", "5432")
    )
    cur = conn.cursor()

    sql = '''CREATE TABLE IF NOT EXISTS datalogiciels(
			  id INT PRIMARY KEY NOT NULL,
			  name TEXT NOT NULL,
			  type_software TEXT NOT NULL,
              version TEXT NOT NULL,
              editor TEXT NOT NULL,
              last_update DATE NOT NULL,
              info_licence TEXT NOT NULL

			); '''
    
    cur.execute(sql)
    conn.commit()
	

except (Exception, ps.Error) as error :
    print ("Erreur lors de la création de la table PostgreSQL", error)

app = Flask(__name__)

navbar_html = [ 
                

                ]

def recupToken():
    if request.cookies.get('token') is not None:
        token = request.cookies.get('token')
    try: 
        with open("/var/lib/kirbi/shared/jwt_rsa.pem", mode="rb") as pubkey:
            try:
                token_decode = jwt.decode(token, pubkey.read(), algorithms="RS256")
                return token_decode
            except jwt.exceptions.InvalidSignatureError:
                return "Invalid signature"
            except jwt.exceptions.DecodeError:
                return "Wrong token format"
            except jwt.ExpiredSignatureError:
                return "Expired token"
            except jwt.exceptions.InvalidAlgorithmError:
                return "Unexpected algorithm"

    except (Exception, ps.Error) as error:
        print ("Authentification n'a pas aboutie", error)
    



@app.route("/")
def accueil():
    token = recupToken()
    print(token)
    if type(token) == dict : 
        if "logiciels" in token["permissions"]["read"]: 
            return render_template("index.html", navbar=navbar_html) 
        else : 
            return jsonify({"message": "403 - Vous ne possèdez pas les droits"}), 403
    else : 
        return jsonify({"message": "403 - Un problème d'authentification est survenu"}), 403


def format_sql(data):
    if type(data) == str:
        return f"'{data}'"
    if type(data) == list:
        if len(data) == 0:
            return
        return f'ARRAY[{", ".join([format_sql(x) for x in data])}]'
    return str(data)

# Récupération des software
@app.route('/software', methods=['GET'])
def recup():
    token = recupToken()
    if type(token) == dict : 
        if "logiciels" in token["permissions"]["read"]: 
            try:    
                commande = f'select * from public.datalogiciels'
                cur.execute(commande)
                resultat = cur.fetchall()
                list_json_logiciels= []
                for logiciel in resultat:
                    list_json_logiciels.append({"id": logiciel[0],
                    "name": logiciel[1],
                    "type_software": logiciel[2],
                    "version": logiciel[3],
                    "editor": logiciel[4],
                    "last_update": logiciel[5],
                    "info_licence": logiciel[6]})
                return jsonify(list_json_logiciels), 200
    
            except (Exception, ps.Error) :
                    return jsonify({'message': "400 - L'opération n'a pas aboutie"}), 400
        else : 
            return jsonify({"message": "403 - Vous ne possèdez pas les droits"}), 403
    else : 
        return jsonify({"message": "403 - Un problème d'authentification est survenu"}), 403

   
    

# Récupération des details d'un software
@app.route('/software/<id>', methods=['GET'])
def recup_software(id):
    token = recupToken()
    if type(token) == dict : 
        if "logiciels" in token["permissions"]["read"]: 
            cur.execute(f" select * from public.datalogiciels where id = '{id}'")
            resultat = cur.fetchall()

            if len (resultat) == 0: 
                return jsonify({'message': "400 - ID introuvable"}), 400
            try:
                cur.execute(f" select * from public.datalogiciels where id = '{id}'")
                resultat = cur.fetchall()
                list_json_logiciel= []
                
                list_json_logiciel.append({"id": resultat[0][0],
                    "name": resultat[0][1],
                    "type_software": resultat[0][2],
                    "version": resultat[0][3],
                    "editor": resultat[0][4],
                    "last_update": resultat[0][5],
                    "info_licence": resultat[0][6]})
                return jsonify(list_json_logiciel), 200
    
            except (Exception, ps.Error)  :
                return jsonify({'message': "500 - L'opération n'a pas aboutie"}), 500
        else : 
            return jsonify({"message": "403 - Vous ne possèdez pas les droits"}), 403
    else : 
        return jsonify({"message": "403 - Un problème d'authentification est survenu"}), 403

   

@app.route('/software', methods=['POST'])
def ajouter():
    token = recupToken()
    if type(token) == dict : 
        if "logiciels" in token["permissions"]["write"]: 
            nouveau = request.json
            cur.execute(f" select * from public.datalogiciels where id = '{nouveau["id"]}'")
            resultat = cur.fetchall()
            if len (resultat) != 0: 
                return jsonify({'message': "400 - ID existe déjà"}), 400
            try:
                cur.execute(f"""
                                insert into public.datalogiciels values ({", ".join([format_sql(logiciel) for logiciel in nouveau.values()])})
                            """)
                conn.commit()
                return jsonify({'message': '200 - Nouveau logiciel ajouté avec succès'}), 200
            except (Exception, ps.Error)  :
                return jsonify({'message': "500 - L'opération n'a pas aboutie"}), 500
        else : 
            return jsonify({"message": "403 - Vous ne possèdez pas les droits"}), 403
    else : 
        return jsonify({"message": "403 - Un problème d'authentification est survenu"}), 403

   

@app.route("/software/<id>", methods=["DELETE"])
def supprimer(id): 
    token = recupToken()
    if type(token) == dict : 
        if "logiciels" in token["permissions"]["write"]: 
            cur.execute(f" select * from public.datalogiciels where id = '{id}'")
            resultat = cur.fetchall()
            if len (resultat) == 0: 
                return jsonify({'message': "ID introuvable"}), 400
   
            try:
       
                cur.execute(f"""
                    delete from public.datalogiciels where id = {id}
                    """)
                conn.commit()
                return jsonify({'message': '200 - Suppression du logiciel avec succès'}), 200

            except (Exception, ps.Error) :
                return jsonify({'message': "500 - L'opération n'a pas aboutie"}), 500

        else : 
            return jsonify({"message": "403 - Vous ne possèdez pas les droits"}), 403
    else : 
        return jsonify({"message": "403 - Un problème d'authentification est survenue"}), 403

        
@app.route("/software/<id>", methods=["PATCH"])
def update(id):
    token = recupToken()
    if type(token) == dict : 
        if "logiciels" in token["permissions"]["write"]: 
            maj = request.json
            cur.execute(f" select * from public.datalogiciels where id = '{id}'")
            resultat = cur.fetchall()
            if len (resultat) == 0: 
                return jsonify({'message': "400 - ID introuvable"}), 400
            try:
        
                cur.execute(f"""
                            UPDATE datalogiciels SET {", ".join([key + " = " + format_sql(value) for key, value in maj.items()])} WHERE id = {id}
                        """)
                conn.commit()
                return jsonify({'message': '200 - Modification du logiciel avec succès'}), 200

            except (Exception, ps.Error) :
                return jsonify({'message': "500 - L'opération n'a pas aboutie"}), 500 
        else : 
            return jsonify({"message": "403 - Vous ne possèdez pas les droits"}), 403
    else : 
        return jsonify({"message": "403 - Un problème d'authentification est survenu"}), 403

    


if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port="5000")
