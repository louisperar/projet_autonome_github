from flask import Flask, render_template

app = Flask(__name__)

# Contenue de la bar de navigation, 1er arg : id | 2eme arg : Nom de l'item de la navbar | 3eme arg : url de redirection
navbar_html = [ {"id":"1", "name":"Affichage des logiciels", "url":"/affichage"}, 
                {"id":"2", "name":"Recherche d'un logiciel", "url":"/recherche"},
                {"id":"3", "name":"Ajout d'un logiciel", "url":"/ajout"},
                {"id":"4", "name":"Supprimer un logiciel", "url":"/suppression"},
                {"id":"5", "name":"Modification d'un logiciel", "url":"/modification"}

                ]


@app.route("/")
def hello_world():
    return render_template("index.html", navbar=navbar_html) # 1er argument nom de la page HTML stockée dans static 

if __name__ == "__main__":
    app.run(debug=True)

