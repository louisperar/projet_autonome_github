
url = "http://127.0.0.1:5000/software"
function search(){
   
 input = document.getElementById("id-search").value;
 fetch(url + "/" + input)
   .then(response => response.json())
   .then(data => {

       const tableBody = document.querySelector('#table-data tbody');
       tableBody.innerHTML = '';

           const row = document.createElement('tr');
           var url_with_id = url + "/" + data[0].id;
           var dateObject = new Date(data[0].last_update);
           var format = dateObject.toLocaleDateString('fr-FR');
           row.innerHTML = `
             <td>${data[0].id}</td>
             <td>${data[0].name}</td>
             <td>${data[0].type_software}</td>
             <td>${data[0].version}</td>
             <td>${data[0].editor}</td>
             <td>${format}</td>
             <td>${data[0].info_licence}</td>
             <td><button type="button" class="btn btn-dark" name="delete"  onClick="del('${url_with_id}')">Suppression</button></td>
             <td><button type="button" class="btn btn-dark" name="modify" onClick="modify('${url_with_id}')">Modification</button></td>
           `;
           document.querySelector('#table-data tbody').appendChild(row);
       
  
   }) 
   .catch(error => {
   
   console.error('Erreur:', error);
   alert("Aucun résultat trouvé")
     fetchData();
    });

}
function modify(url) {
 $('#modalModify').modal('show');
 fetch(url)

       .then(response => response.json())
       .then(data => {
       document.getElementById('id').value = data[0].id;
       document.getElementById('name').value = data[0].name;
       document.getElementById('type_software').value = data[0].type_software ;
       document.getElementById('version').value = data[0].version;
       document.getElementById('editor').value = data[0].editor;
       document.getElementById('last_update').valueAsDate = data[0].last_update;
       document.getElementById('info_licence').value = data[0].info_licence ;
       })
       .catch(error => console.error('Erreur:', error));
};
function ok_modify(){
 fetch(url + "/" + document.getElementById('id').value , {
 method: 'PATCH',
 headers: {
 'Content-Type': 'application/json',
 },
 body: JSON.stringify({ id: document.getElementById('id').value, name: document.getElementById('name').value, type_software: document.getElementById('type_software').value, version: document.getElementById('version').value, editor: document.getElementById('editor').value, last_update: document.getElementById('last_update').value, info_licence: document.getElementById('info_licence').value, })
 })
 .then(() => fetchData());

}
function del(url) {
 fetch(url, { method: 'DELETE' })
   .then(() => fetchData());
 };

function fetchData() {
     fetch(url)
       .then(response => response.json())
       .then(data => {

       const tableBody = document.querySelector('#table-data tbody');
       tableBody.innerHTML = '';

         data.forEach(entry => {
           const row = document.createElement('tr');
           var url_with_id = url + "/" + entry.id;

           var dateObject = new Date(entry.last_update);
           var format = dateObject.toLocaleDateString('fr-FR');

           row.innerHTML = `
             <td>${entry.id}</td> 
             <td>${entry.name}</td>
             <td>${entry.type_software}</td>
             <td>${entry.version}</td>
             <td>${entry.editor}</td>
             <td>${format}</td>
             <td>${entry.info_licence}</td>
       
             <td><button type="button" class="btn btn-dark" name="delete"  onClick="del('${url_with_id}')">Suppression</button></td>
             <td><button type="button" class="btn btn-dark" name="modify" onClick="modify('${url_with_id}')">Modification</button></td>

           `;
           document.querySelector('#table-data tbody').appendChild(row);
         });
       })
       .catch(error => alert('Erreur', error));
   }
function add() {
 
 if (document.getElementById('id-add').value > 0) {
 fetch(url, {
 method: "POST",
 headers: { "Content-type": "application/json" },
 body: JSON.stringify({ id: document.getElementById('id-add').value, name: document.getElementById('name-add').value, type_software: document.getElementById('type_software-add').value, version: document.getElementById('version-add').value, editor: document.getElementById('editor-add').value, last_update: document.getElementById('last_update-add').value, info_licence: document.getElementById('info_licence-add').value })
 })
 .then(response => {
     if (response.status == "400"){
       alert('ID déjà utilisé ');
     }
   })
 .then(() => fetchData())

    
 } else {
   alert('ID doit être supérieur à 0');
 }
}
   window.onload = fetchData;
