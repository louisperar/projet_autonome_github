import requests
import json


url = 'http://127.0.0.1:5000/software'
data = {
        "id": 1,
        "name": "PowerPoint",
        "type_software": "Slide treatment",
        "version": "16.4.4",
        "editor": "Microsoft",
        "last_update": "2024-02-05",
        "info_licence": "Licence Microsoft Office Valide jusquau ..."
    }


rq = requests.post(url, json = data)
print(rq.json())

url = 'http://127.0.0.1:5000/software'
data = {
        "id": 2,
        "name": "Excel",
        "type_software": "Data treatment",
        "version": "10.4.4",
        "editor": "Microsoft",
        "last_update": "2024-01-05",
        "info_licence": "Licence Microsoft Office Valide jusquau ..."
    }


rq = requests.post(url, json = data)
print(rq.json())


url = 'http://127.0.0.1:5000/software'
data = {
        "id": 3,
        "name": "Word",
        "type_software": "Text treatment",
        "version": "12.4.4",
        "editor": "Microsoft",
        "last_update": "2022-06-10",
        "info_licence": "Licence Microsoft Office Valide jusquau ..."
    }


rq = requests.post(url, json = data)
print(rq.json())

url = 'http://127.0.0.1:5000/software'
data = {
        "id": 4,
        "name": "VS Code",
        "type_software": "Code",
        "version": "10.4.4",
        "editor": "Microsoft",
        "last_update": "2021-09-09",
        "info_licence": "Info licence API"
    }


rq = requests.post(url, json = data)
print(rq.json())

url = 'http://127.0.0.1:5000/software'
data = {
        "id": 5,
        "name": "Android Studio",
        "type_software": "Code",
        "version": "20.4.4",
        "editor": "Android",
        "last_update": "2020-03-04",
        "info_licence": "Info licence API"
    }


rq = requests.post(url, json = data)
print(rq.json())

response = requests.get('http://127.0.0.1:5000/software/1')
print(response.json())

#response = requests.delete('http://127.0.0.1:5000/software/2')
#print(response.json())

data = {"version": "18.0.0", "last_update": "12/05/2023" } 
response = requests.patch(f'http://127.0.0.1:5000/software/1', json=data)
print(response.json())